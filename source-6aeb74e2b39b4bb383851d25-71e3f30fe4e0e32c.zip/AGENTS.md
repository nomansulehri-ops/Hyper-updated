# AGENTS.md — HyperPanda SuperStore

**Start here:** read `PLAN.md`. Milestone 1 (storefront and admin UI) is done. Continue with Milestone 2.

## Architecture
- TanStack Start + React 19 + Tailwind v4, deployed on Netlify (`netlify.toml`: `vite build` → `dist/client`).
- **All store data flows through one context**: `src/lib/store.tsx` (`StoreProvider`, `useStore()`). It holds settings, banners, tiles, categories, products, orders and the cart. Screens only call the named actions (`saveProduct`, `saveBanner`, `saveTile`, `saveCategory`, `remove`, `move`, `updateSettings`, `updateOrder`, `placeOrder`, `addToCart`, `setQty`).
- **Seed data** lives in `src/data/fixtures.ts`, and the types are in `src/data/types.ts`. When adding persistence, put each action behind a server function and load the initial state from the DB. Keep the action signatures the same so the screens don't change.
- The cart is per device and is stored in `localStorage` (`hp-cart`). Everything else is currently in memory only.
- Theme: brand colours are Tailwind `@theme` variables (`--color-brand`, `--color-accent`, `--color-ink`, plus `panel`, `line`, `snow`, `mist`) in `src/styles.css`. `__root.tsx` overrides the first three at runtime from `settings.theme`, which is how the admin recolours the store live.

## Key directories
- `src/routes/`: `index` (home), `shop` (search params `c`, `q`, `sort`), `products/$productId`, `checkout`, `order/$orderId`, `track`, `admin` (search param `tab`).
- `src/components/`: storefront pieces (Header, Footer + WhatsAppFab, CartDrawer, HeroCarousel, ProductCard, OrderTracker, Logo, SmartLink).
- `src/components/admin/`: admin screens plus `ui.tsx` primitives (Field, Modal, Toggle, ImageInput, Card, PageHeader).
- `public/img/`: generated hero banners (`hero-1..3.png`), `storefront.jpg`, and `products/<darazItemId>.jpg`.

## Conventions
- Always render local images through `img(src, width)` from `src/lib/format.ts`, which uses the Netlify Image CDN. Data URLs and remote URLs pass through unchanged.
- Prices are whole PKR numbers. Format them with `money(n, settings.currency)`.
- Use `SmartLink` for links the admin can edit (banner CTAs, tiles) so internal paths navigate client-side and don't reload the page.
- The `/admin` route renders without the storefront header and footer (see `Shell` in `__root.tsx`).
- The default logo is the SVG `PandaMark` + wordmark in `Logo.tsx`. An uploaded `settings.logoUrl` replaces it.

## Non-obvious notes
- The template's Stripe checkout was removed in favour of Cash on Delivery. The unused `stripe` dependency is still in `package.json`, so the lockfile stays in sync.
- `/admin` is behind username/password sign-in (`src/lib/auth.ts`, tables in `db/schema.ts`). The store actions themselves are still client-side, so server-side checks are needed once they persist (Milestone 2).
- Product data was imported from the HyperPanda Daraz shop (seller shop `jtqbqobj`).
