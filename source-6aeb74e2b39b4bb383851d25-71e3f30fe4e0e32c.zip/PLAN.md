# HyperPanda SuperStore — Product roadmap

The goal is a cinematic online store for HyperPanda SuperStore (PECHS Phase 6, Karachi) where customers can shop and order with Cash on Delivery, and the owner can manage everything (logo, banners, tiles, products, orders, tracking, contact details) from an admin portal in the browser.

## Milestone 1 — Storefront and admin portal ✅ (done)
- Cinematic storefront: full-screen hero slideshow, trust strip, category row, promo tile mosaic, flash deals with countdown, best sellers, store visit section, reviews, FAQ, and a floating WhatsApp button.
- Shop page with category filters, search and sorting. Product pages with gallery, discount, stock level, Buy now, and Order on WhatsApp.
- Cart drawer with a free-delivery progress bar, a Cash on Delivery checkout, an order confirmation page, and a Track Order page.
- Admin portal at `/admin`: dashboard, orders and tracking, products, hero banners, promo tiles, categories, and branding and settings (logo upload, theme colours, contact details, delivery fees, announcement bar).
- The 14 products in the HyperPanda Daraz shop are imported with their photos and prices.
- Data is seeded from `src/data/fixtures.ts` and managed in one store context (`src/lib/store.tsx`). Admin edits show up on the storefront straight away but reset when the page reloads.

## Milestone 2 — Persistent catalogue and content
- Netlify Database (Drizzle) tables for settings, banners, tiles, categories and products, seeded from the fixtures.
- Server functions for every store action (`saveProduct`, `saveBanner`, `updateSettings`, …). The screens keep the same calls.
- Uploaded logos, banners and product photos go to Netlify Blobs and are served through the Image CDN.

## Milestone 3 — Real orders and tracking
- `orders` and `order_events` tables. Checkout calls a server function that checks prices and stock on the server and gives out sequential order numbers.
- Track Order looks up orders on the server by order number and phone number.
- Status changes and courier or tracking details are saved, and each change is logged in the order history.

## Milestone 4 — Admin sign-in and roles (sign-in done early)
- ✅ Done ahead of schedule: username/password sign-in for `/admin` (Netlify Database `admin_users` + `admin_sessions`, scrypt-hashed passwords, HTTP-only session cookie) and an **Admin accounts** tab to add, re-key and remove accounts. Owner account `noman789` is created on the first sign-in attempt. Store-data actions are not yet checked on the server.
- Netlify Identity login for `/admin`, with an `admin` role (and later a `staff` role).
- Every admin server function rejects requests from anyone without the role.

## Milestone 5 — Notifications and growth
- Email (and optionally WhatsApp Business API) messages when an order is placed or shipped.
- Discount codes, newsletter signup (Netlify Forms), and product reviews from verified buyers.
- Optional online payments (JazzCash / Easypaisa / card) next to COD.
- SEO: product structured data, sitemap, per-product social images.
