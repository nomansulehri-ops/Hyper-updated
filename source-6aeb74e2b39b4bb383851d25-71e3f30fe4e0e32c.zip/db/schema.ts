import { integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core'

/** People who can sign in to /admin. */
export const adminUsers = pgTable('admin_users', {
  id: serial().primaryKey(),
  username: text().notNull().unique(),
  name: text().notNull().default(''),
  passwordHash: text('password_hash').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

/** Signed-in admin sessions. Only a SHA-256 of the cookie token is stored. */
export const adminSessions = pgTable('admin_sessions', {
  tokenHash: text('token_hash').primaryKey(),
  userId: integer('user_id')
    .notNull()
    .references(() => adminUsers.id, { onDelete: 'cascade' }),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})
