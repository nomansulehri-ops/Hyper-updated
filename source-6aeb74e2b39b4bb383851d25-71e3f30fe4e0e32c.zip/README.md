# HyperPanda SuperStore

A cinematic online store for **HyperPanda SuperStore** (PECHS Phase 6, Karachi). It covers gadgets, modest fashion, home and beauty essentials, with Cash on Delivery all over Pakistan and an admin portal where the owner manages the whole store from the browser.

- Customer care: WhatsApp +92 339 0112789 · hyperpandasuperstore@gmail.com

## What's inside
- **Storefront**: home page with a hero slideshow, categories, promo tiles, flash deals, best sellers, reviews and FAQ. Also a shop page with filters, product pages, cart drawer, COD checkout, order confirmation and order tracking.
- **Admin portal** (`/admin`): dashboard, orders and tracking, products, hero banners, promo tiles, categories, and branding and settings.

## Tech
TanStack Start (React 19), Tailwind CSS v4, lucide icons. Hosted on Netlify, with images served through the Netlify Image CDN. The banner artwork was generated with Netlify AI Gateway (Gemini).

## Run locally
```bash
pnpm install
netlify dev   # or: pnpm dev
```
Open http://localhost:8888 for the store and http://localhost:8888/admin for the admin portal.

## Roadmap
Right now the catalogue, content and orders come from `src/data/fixtures.ts`, and admin edits last only for the browser session. Next steps, in order: database persistence for products and content, real order storage and tracking, admin sign-in, and notifications. See [PLAN.md](./PLAN.md).
