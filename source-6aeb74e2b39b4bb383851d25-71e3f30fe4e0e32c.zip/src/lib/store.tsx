import { createContext, useContext, useEffect, useMemo, useReducer } from 'react'
import type { ReactNode } from 'react'
import {
  seedBanners,
  seedCategories,
  seedOrders,
  seedProducts,
  seedSettings,
  seedTiles,
} from '@/data/fixtures'
import type {
  Banner,
  CartLine,
  Category,
  Order,
  OrderStatus,
  Product,
  StoreSettings,
  Tile,
} from '@/data/types'

/**
 * Single source of truth for the storefront and the admin portal.
 *
 * Today the state is seeded from `src/data/fixtures.ts` and lives in the
 * browser session. Every mutation goes through one of the named actions
 * below so the database milestone can swap each one for a server function
 * without touching the screens.
 */
interface State {
  settings: StoreSettings
  banners: Array<Banner>
  tiles: Array<Tile>
  categories: Array<Category>
  products: Array<Product>
  orders: Array<Order>
  cart: Array<CartLine>
  cartOpen: boolean
}

type Action =
  | { type: 'settings'; patch: Partial<StoreSettings> }
  | { type: 'upsert'; key: 'banners' | 'tiles' | 'categories' | 'products'; item: { id: string } }
  | { type: 'remove'; key: 'banners' | 'tiles' | 'categories' | 'products'; id: string }
  | { type: 'move'; key: 'banners' | 'tiles'; id: string; dir: -1 | 1 }
  | { type: 'order:add'; order: Order }
  | { type: 'order:update'; id: string; patch: Partial<Order>; note?: string }
  | { type: 'cart:set'; cart: Array<CartLine> }
  | { type: 'cart:open'; open: boolean }

function reducer(state: State, a: Action): State {
  switch (a.type) {
    case 'settings':
      return { ...state, settings: { ...state.settings, ...a.patch } }
    case 'upsert': {
      const list = state[a.key] as Array<{ id: string }>
      const exists = list.some((x) => x.id === a.item.id)
      return {
        ...state,
        [a.key]: exists
          ? list.map((x) => (x.id === a.item.id ? a.item : x))
          : [a.item, ...list],
      }
    }
    case 'remove':
      return {
        ...state,
        [a.key]: (state[a.key] as Array<{ id: string }>).filter((x) => x.id !== a.id),
      }
    case 'move': {
      const list = [...state[a.key]] as Array<{ id: string }>
      const i = list.findIndex((x) => x.id === a.id)
      const j = i + a.dir
      if (i < 0 || j < 0 || j >= list.length) return state
      ;[list[i], list[j]] = [list[j], list[i]]
      return { ...state, [a.key]: list }
    }
    case 'order:add':
      return { ...state, orders: [a.order, ...state.orders] }
    case 'order:update':
      return {
        ...state,
        orders: state.orders.map((o) => {
          if (o.id !== a.id) return o
          const next = { ...o, ...a.patch }
          if (a.patch.status && a.patch.status !== o.status) {
            next.timeline = [
              ...o.timeline,
              { status: a.patch.status, note: a.note || STATUS_LABEL[a.patch.status], at: new Date().toISOString() },
            ]
          }
          return next
        }),
      }
    case 'cart:set':
      return { ...state, cart: a.cart }
    case 'cart:open':
      return { ...state, cartOpen: a.open }
  }
}

export const STATUS_LABEL: Record<OrderStatus, string> = {
  pending: 'Order placed',
  confirmed: 'Confirmed',
  packed: 'Packed',
  shipped: 'Shipped',
  out_for_delivery: 'Out for delivery',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
}

export const STATUS_FLOW: Array<OrderStatus> = [
  'pending',
  'confirmed',
  'packed',
  'shipped',
  'out_for_delivery',
  'delivered',
]

const initial: State = {
  settings: seedSettings,
  banners: seedBanners,
  tiles: seedTiles,
  categories: seedCategories,
  products: seedProducts,
  orders: seedOrders,
  cart: [],
  cartOpen: false,
}

const Ctx = createContext<ReturnType<typeof useStoreValue> | null>(null)

const CART_KEY = 'hp-cart'

function useStoreValue() {
  const [state, dispatch] = useReducer(reducer, initial)

  // The shopping cart is per-device, so it is kept in the browser.
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(CART_KEY) || '[]')
      if (Array.isArray(saved)) dispatch({ type: 'cart:set', cart: saved })
    } catch {
      /* ignore */
    }
  }, [])
  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(state.cart))
  }, [state.cart])

  return useMemo(() => {
    const productById = (id: string) => state.products.find((p) => p.id === id)
    const cartItems = state.cart
      .map((l) => ({ ...l, product: productById(l.productId) }))
      .filter((l): l is CartLine & { product: Product } => !!l.product)
    const subtotal = cartItems.reduce((s, l) => s + l.product.price * l.qty, 0)
    const shipping =
      subtotal === 0 || subtotal >= state.settings.freeShippingThreshold
        ? 0
        : state.settings.shippingFee

    return {
      ...state,
      productById,
      cartItems,
      cartCount: cartItems.reduce((s, l) => s + l.qty, 0),
      subtotal,
      shipping,
      total: subtotal + shipping,

      updateSettings: (patch: Partial<StoreSettings>) => dispatch({ type: 'settings', patch }),
      saveBanner: (item: Banner) => dispatch({ type: 'upsert', key: 'banners', item }),
      saveTile: (item: Tile) => dispatch({ type: 'upsert', key: 'tiles', item }),
      saveCategory: (item: Category) => dispatch({ type: 'upsert', key: 'categories', item }),
      saveProduct: (item: Product) => dispatch({ type: 'upsert', key: 'products', item }),
      remove: (key: 'banners' | 'tiles' | 'categories' | 'products', id: string) =>
        dispatch({ type: 'remove', key, id }),
      move: (key: 'banners' | 'tiles', id: string, dir: -1 | 1) =>
        dispatch({ type: 'move', key, id, dir }),
      updateOrder: (id: string, patch: Partial<Order>, note?: string) =>
        dispatch({ type: 'order:update', id, patch, note }),

      openCart: (open = true) => dispatch({ type: 'cart:open', open }),
      addToCart: (productId: string, qty = 1) => {
        const has = state.cart.find((l) => l.productId === productId)
        dispatch({
          type: 'cart:set',
          cart: has
            ? state.cart.map((l) => (l.productId === productId ? { ...l, qty: l.qty + qty } : l))
            : [...state.cart, { productId, qty }],
        })
        dispatch({ type: 'cart:open', open: true })
      },
      setQty: (productId: string, qty: number) =>
        dispatch({
          type: 'cart:set',
          cart:
            qty <= 0
              ? state.cart.filter((l) => l.productId !== productId)
              : state.cart.map((l) => (l.productId === productId ? { ...l, qty } : l)),
        }),
      placeOrder: (customer: Order['customer']): Order => {
        const now = new Date().toISOString()
        const maxId = Math.max(10000, ...state.orders.map((o) => Number(o.id.replace(/\D/g, '')) || 0))
        const order: Order = {
          id: `HP-${maxId + 1}`,
          createdAt: now,
          customer,
          items: cartItems.map((l) => ({
            productId: l.productId,
            name: l.product.name,
            image: l.product.image,
            price: l.product.price,
            qty: l.qty,
          })),
          subtotal,
          shipping,
          total: subtotal + shipping,
          payment: 'COD',
          status: 'pending',
          courier: '',
          trackingNumber: '',
          timeline: [{ status: 'pending', note: 'Order placed on website', at: now }],
        }
        dispatch({ type: 'order:add', order })
        for (const l of cartItems) {
          dispatch({
            type: 'upsert',
            key: 'products',
            item: { ...l.product, stock: Math.max(0, l.product.stock - l.qty) },
          })
        }
        dispatch({ type: 'cart:set', cart: [] })
        return order
      },
    }
  }, [state])
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const value = useStoreValue()
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useStore() {
  const v = useContext(Ctx)
  if (!v) throw new Error('useStore must be used inside <StoreProvider>')
  return v
}
