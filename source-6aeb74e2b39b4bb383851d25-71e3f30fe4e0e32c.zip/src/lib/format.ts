export function money(n: number, currency = 'Rs.') {
  return `${currency} ${Math.round(n).toLocaleString('en-PK')}`
}

export function discountPct(price: number, original?: number) {
  if (!original || original <= price) return 0
  return Math.round(((original - price) / original) * 100)
}

/**
 * Serve local images through the Netlify Image CDN so pages never ship
 * full-resolution originals. Uploaded (data:) and remote URLs pass through.
 */
export function img(src: string, w: number, q = 78) {
  if (!src || !src.startsWith('/')) return src
  return `/.netlify/images?url=${encodeURIComponent(src)}&w=${w}&fm=webp&q=${q}`
}

export function waLink(number: string, text = '') {
  const n = number.replace(/\D/g, '')
  return `https://wa.me/${n}${text ? `?text=${encodeURIComponent(text)}` : ''}`
}

export function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}`
}

export function fmtDate(iso: string) {
  return new Date(iso).toLocaleString('en-PK', {
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
  })
}

/** Read a picked file as a data URL (used for logo / banner / product uploads). */
export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result))
    r.onerror = reject
    r.readAsDataURL(file)
  })
}
