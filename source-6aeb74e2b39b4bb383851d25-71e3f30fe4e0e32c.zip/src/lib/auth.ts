import { createServerFn } from '@tanstack/react-start'
import { deleteCookie, getCookie, setCookie } from '@tanstack/react-start/server'
import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto'
import { and, asc, count, eq, gt, lt } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { adminSessions, adminUsers } from '../../db/schema.js'

export type AdminUser = { id: number; username: string; name: string; createdAt: string }

const COOKIE = 'hp_admin'
const SESSION_DAYS = 30

/** The owner account created automatically the first time anyone tries to sign in. */
const OWNER = { username: 'noman789', password: 'nomi@789', name: 'Noman' }

// ---------- server-only helpers ----------

function hashPassword(password: string) {
  const salt = randomBytes(16)
  const key = scryptSync(password, salt, 64)
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`
}

function verifyPassword(password: string, stored: string) {
  const [algo, salt, key] = stored.split('$')
  if (algo !== 'scrypt' || !salt || !key) return false
  const expected = Buffer.from(key, 'base64')
  const actual = scryptSync(password, Buffer.from(salt, 'base64'), expected.length)
  return timingSafeEqual(actual, expected)
}

const sha256 = (s: string) => createHash('sha256').update(s).digest('hex')

const toUser = (u: typeof adminUsers.$inferSelect): AdminUser => ({
  id: u.id,
  username: u.username,
  name: u.name,
  createdAt: u.createdAt.toISOString(),
})

async function ensureOwnerAccount() {
  const [{ n }] = await db.select({ n: count() }).from(adminUsers)
  if (n > 0) return
  await db
    .insert(adminUsers)
    .values({ username: OWNER.username, name: OWNER.name, passwordHash: hashPassword(OWNER.password) })
    .onConflictDoNothing()
}

async function currentUser(): Promise<AdminUser | null> {
  const token = getCookie(COOKIE)
  if (!token) return null
  const [row] = await db
    .select({ user: adminUsers })
    .from(adminSessions)
    .innerJoin(adminUsers, eq(adminSessions.userId, adminUsers.id))
    .where(and(eq(adminSessions.tokenHash, sha256(token)), gt(adminSessions.expiresAt, new Date())))
    .limit(1)
  return row ? toUser(row.user) : null
}

async function requireUser() {
  const user = await currentUser()
  if (!user) throw new Error('Please sign in to the admin portal.')
  return user
}

const cleanUsername = (s: unknown) => String(s ?? '').trim().toLowerCase()

// ---------- server functions ----------

export const getAdminSession = createServerFn({ method: 'GET' }).handler(async () => currentUser())

export const adminLogin = createServerFn({ method: 'POST' })
  .validator((d: { username: string; password: string }) => ({
    username: cleanUsername(d?.username),
    password: String(d?.password ?? ''),
  }))
  .handler(async ({ data }) => {
    await ensureOwnerAccount()
    const [u] = await db.select().from(adminUsers).where(eq(adminUsers.username, data.username)).limit(1)
    if (!u || !verifyPassword(data.password, u.passwordHash)) {
      throw new Error('Incorrect username or password.')
    }
    const token = randomBytes(32).toString('base64url')
    const expiresAt = new Date(Date.now() + SESSION_DAYS * 864e5)
    await db.delete(adminSessions).where(lt(adminSessions.expiresAt, new Date()))
    await db.insert(adminSessions).values({ tokenHash: sha256(token), userId: u.id, expiresAt })
    setCookie(COOKIE, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      expires: expiresAt,
    })
    return toUser(u)
  })

export const adminLogout = createServerFn({ method: 'POST' }).handler(async () => {
  const token = getCookie(COOKIE)
  if (token) await db.delete(adminSessions).where(eq(adminSessions.tokenHash, sha256(token)))
  deleteCookie(COOKIE, { path: '/' })
  return true
})

export const listAdmins = createServerFn({ method: 'GET' }).handler(async () => {
  await requireUser()
  const rows = await db.select().from(adminUsers).orderBy(asc(adminUsers.createdAt))
  return rows.map(toUser)
})

export const createAdmin = createServerFn({ method: 'POST' })
  .validator((d: { name: string; username: string; password: string }) => {
    const username = cleanUsername(d?.username)
    const password = String(d?.password ?? '')
    const name = String(d?.name ?? '').trim().slice(0, 80)
    if (!/^[a-z0-9._@-]{3,32}$/.test(username)) {
      throw new Error('Username must be 3–32 characters: letters, numbers, . _ - or @')
    }
    if (password.length < 6) throw new Error('Password must be at least 6 characters.')
    return { name, username, password }
  })
  .handler(async ({ data }) => {
    await requireUser()
    const [row] = await db
      .insert(adminUsers)
      .values({ name: data.name, username: data.username, passwordHash: hashPassword(data.password) })
      .onConflictDoNothing()
      .returning()
    if (!row) throw new Error(`The username “${data.username}” is already taken.`)
    return toUser(row)
  })

export const updateAdminPassword = createServerFn({ method: 'POST' })
  .validator((d: { id: number; password: string }) => {
    const password = String(d?.password ?? '')
    if (password.length < 6) throw new Error('Password must be at least 6 characters.')
    return { id: Number(d?.id), password }
  })
  .handler(async ({ data }) => {
    await requireUser()
    await db.update(adminUsers).set({ passwordHash: hashPassword(data.password) }).where(eq(adminUsers.id, data.id))
    return true
  })

export const deleteAdmin = createServerFn({ method: 'POST' })
  .validator((d: { id: number }) => ({ id: Number(d?.id) }))
  .handler(async ({ data }) => {
    const me = await requireUser()
    if (me.id === data.id) throw new Error('You can’t delete the account you are signed in with.')
    await db.delete(adminUsers).where(eq(adminUsers.id, data.id))
    return true
  })
