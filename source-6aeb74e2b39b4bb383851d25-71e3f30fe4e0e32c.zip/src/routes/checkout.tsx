import { Link, createFileRoute, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { Lock, Wallet } from 'lucide-react'
import { useStore } from '@/lib/store'
import { img, money } from '@/lib/format'

export const Route = createFileRoute('/checkout')({
  head: () => ({ meta: [{ title: 'Checkout — HyperPanda SuperStore' }] }),
  component: Checkout,
})

const CITIES = ['Karachi', 'Lahore', 'Islamabad', 'Rawalpindi', 'Faisalabad', 'Multan', 'Hyderabad', 'Peshawar', 'Quetta', 'Sialkot', 'Gujranwala', 'Other']

function Checkout() {
  const { cartItems, subtotal, shipping, total, placeOrder, settings } = useStore()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', phone: '', email: '', city: 'Karachi', address: '', notes: '' })
  const [error, setError] = useState('')
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }))

  if (cartItems.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-6 py-32 text-center">
        <h1 className="font-display text-3xl font-bold">Your cart is empty</h1>
        <Link to="/shop" className="btn btn-brand mt-8">Continue shopping</Link>
      </div>
    )
  }

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!/^(\+?92|0)3\d{9}$/.test(form.phone.replace(/[\s-]/g, ''))) {
      setError('Please enter a valid Pakistani mobile number, e.g. 03001234567')
      return
    }
    const order = placeOrder({ ...form, phone: form.phone.replace(/[\s-]/g, '') })
    navigate({ to: '/order/$orderId', params: { orderId: order.id } })
  }

  return (
    <div className="mx-auto max-w-6xl px-4 pt-10 md:px-6">
      <h1 className="font-display text-4xl font-extrabold">Checkout</h1>
      <p className="mt-2 text-mist">No advance payment — pay the rider when your parcel arrives.</p>

      <form onSubmit={submit} className="mt-8 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-5 rounded-3xl border border-line bg-panel/60 p-6 md:p-8">
          <h2 className="font-display text-lg font-bold">Delivery details</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Full name"><input required value={form.name} onChange={set('name')} className="input" placeholder="Ayesha Khan" /></Field>
            <Field label="Mobile number (WhatsApp)"><input required value={form.phone} onChange={set('phone')} className="input" placeholder="03001234567" inputMode="tel" /></Field>
            <Field label="Email (optional)"><input type="email" value={form.email} onChange={set('email')} className="input" placeholder="you@example.com" /></Field>
            <Field label="City">
              <select value={form.city} onChange={set('city')} className="input">{CITIES.map((c) => <option key={c}>{c}</option>)}</select>
            </Field>
          </div>
          <Field label="Complete address"><textarea required rows={3} value={form.address} onChange={set('address')} className="input" placeholder="House #, street, area, landmark" /></Field>
          <Field label="Order notes (optional)"><input value={form.notes} onChange={set('notes')} className="input" placeholder="e.g. call before delivery" /></Field>

          <div className="flex items-center gap-4 rounded-2xl border border-brand/50 bg-brand/10 p-4">
            <Wallet className="text-brand" />
            <div>
              <p className="font-bold">Cash on Delivery</p>
              <p className="text-xs text-mist">Pay {money(total, settings.currency)} in cash when your order arrives.</p>
            </div>
            <span className="ml-auto grid h-5 w-5 place-items-center rounded-full border-2 border-brand"><span className="h-2.5 w-2.5 rounded-full bg-brand" /></span>
          </div>
          {error && <p className="rounded-xl bg-accent/15 px-4 py-3 text-sm font-semibold text-accent">{error}</p>}
        </div>

        <aside className="h-fit space-y-4 rounded-3xl border border-line bg-panel/60 p-6 lg:sticky lg:top-40">
          <h2 className="font-display text-lg font-bold">Order summary</h2>
          <ul className="space-y-3">
            {cartItems.map((l) => (
              <li key={l.productId} className="flex items-center gap-3">
                <div className="relative">
                  <img src={img(l.product.image, 120)} alt="" className="h-14 w-14 rounded-xl bg-white object-cover" />
                  <span className="absolute -right-2 -top-2 grid h-5 w-5 place-items-center rounded-full bg-brand text-[11px] font-bold text-ink">{l.qty}</span>
                </div>
                <p className="line-clamp-2 flex-1 text-sm">{l.product.name}</p>
                <p className="text-sm font-bold">{money(l.product.price * l.qty, settings.currency)}</p>
              </li>
            ))}
          </ul>
          <div className="space-y-2 border-t border-line pt-4 text-sm">
            <div className="flex justify-between text-mist"><span>Subtotal</span><span>{money(subtotal, settings.currency)}</span></div>
            <div className="flex justify-between text-mist"><span>Delivery</span><span>{shipping === 0 ? 'Free' : money(shipping, settings.currency)}</span></div>
            <div className="flex justify-between font-display text-xl font-bold"><span>Total</span><span className="text-brand">{money(total, settings.currency)}</span></div>
          </div>
          <button type="submit" className="btn btn-brand w-full py-4 text-base"><Lock size={16} /> Place order</button>
          <p className="text-center text-xs text-mist">We confirm every order on WhatsApp before dispatch.</p>
        </aside>
      </form>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-mist">{label}</span>
      {children}
    </label>
  )
}
