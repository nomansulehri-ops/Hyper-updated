import { Link, createFileRoute, useNavigate } from '@tanstack/react-router'
import { SlidersHorizontal } from 'lucide-react'
import { useStore } from '@/lib/store'
import { discountPct } from '@/lib/format'
import { ProductCard } from '@/components/ProductCard'

type ShopSearch = { c?: string; q?: string; sort?: string }

export const Route = createFileRoute('/shop')({
  validateSearch: (s: Record<string, unknown>): ShopSearch => ({
    c: typeof s.c === 'string' ? s.c : undefined,
    q: typeof s.q === 'string' ? s.q : undefined,
    sort: typeof s.sort === 'string' ? s.sort : undefined,
  }),
  head: () => ({ meta: [{ title: 'Shop all — HyperPanda SuperStore' }] }),
  component: Shop,
})

const SORTS = [
  { id: 'popular', label: 'Most popular' },
  { id: 'deals', label: 'Biggest discount' },
  { id: 'low', label: 'Price: low to high' },
  { id: 'high', label: 'Price: high to low' },
]

function Shop() {
  const { c, q, sort = 'popular' } = Route.useSearch()
  const navigate = useNavigate({ from: '/shop' })
  const { products, categories } = useStore()
  const cat = categories.find((x) => x.id === c)

  let list = products.filter((p) => p.active)
  if (c) list = list.filter((p) => p.category === c)
  if (q) {
    const t = q.toLowerCase()
    list = list.filter((p) => `${p.name} ${p.description}`.toLowerCase().includes(t))
  }
  list = [...list].sort((a, b) => {
    if (sort === 'deals') return discountPct(b.price, b.originalPrice) - discountPct(a.price, a.originalPrice)
    if (sort === 'low') return a.price - b.price
    if (sort === 'high') return b.price - a.price
    return b.reviews - a.reviews
  })

  return (
    <div className="mx-auto max-w-7xl px-4 pt-10 md:px-6">
      <div className="relative overflow-hidden rounded-[2rem] border border-line bg-[radial-gradient(ellipse_at_top_left,color-mix(in_oklab,var(--color-brand)_30%,transparent),transparent_60%)] px-8 py-12">
        <p className="text-xs font-bold uppercase tracking-[0.25em] text-brand">{cat ? 'Category' : q ? 'Search' : 'Catalogue'}</p>
        <h1 className="mt-2 font-display text-4xl font-extrabold md:text-5xl">
          {cat ? cat.name : q ? `“${q}”` : 'Shop all products'}
        </h1>
        <p className="mt-2 text-mist">{cat?.blurb ?? `${list.length} products · Cash on Delivery nationwide`}</p>
      </div>

      <div className="sticky top-[92px] z-20 -mx-4 mt-6 flex flex-wrap items-center gap-2 border-b border-line bg-ink/85 px-4 py-3 backdrop-blur-xl md:static md:mx-0 md:border-0 md:bg-transparent md:px-0">
        <Chip active={!c} onClick={() => navigate({ search: (s) => ({ ...s, c: undefined }) })}>All</Chip>
        {categories.map((x) => (
          <Chip key={x.id} active={c === x.id} onClick={() => navigate({ search: (s) => ({ ...s, c: x.id }) })}>
            {x.name}
          </Chip>
        ))}
        <label className="ml-auto flex items-center gap-2 text-sm text-mist">
          <SlidersHorizontal size={16} />
          <select
            value={sort}
            onChange={(e) => navigate({ search: (s) => ({ ...s, sort: e.target.value }) })}
            className="rounded-full border border-line bg-panel px-3 py-2 text-sm text-snow outline-none"
          >
            {SORTS.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
          </select>
        </label>
      </div>

      {list.length === 0 ? (
        <div className="py-24 text-center">
          <p className="font-display text-2xl font-bold">No products found</p>
          <Link to="/shop" className="btn btn-brand mt-6">Clear filters</Link>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {list.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>
      )}
    </div>
  )
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
        active ? 'border-brand bg-brand text-ink' : 'border-line text-mist hover:border-brand/50 hover:text-snow'
      }`}
    >
      {children}
    </button>
  )
}
