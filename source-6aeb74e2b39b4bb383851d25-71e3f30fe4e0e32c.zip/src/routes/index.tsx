import { Link, createFileRoute } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import {
  ArrowRight,
  BadgeCheck,
  ChevronDown,
  MapPin,
  MessageCircle,
  RotateCcw,
  Star,
  Truck,
  Wallet,
} from 'lucide-react'
import { useStore } from '@/lib/store'
import { discountPct, img, waLink } from '@/lib/format'
import { faqs, reviews } from '@/data/fixtures'
import { HeroCarousel } from '@/components/HeroCarousel'
import { ProductCard } from '@/components/ProductCard'
import { SmartLink } from '@/components/SmartLink'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  const { products, categories, tiles, settings } = useStore()
  const live = products.filter((p) => p.active)
  const featured = live.filter((p) => p.featured)
  const deals = [...live]
    .sort((a, b) => discountPct(b.price, b.originalPrice) - discountPct(a.price, a.originalPrice))
    .slice(0, 8)
  const activeTiles = tiles.filter((t) => t.active)

  return (
    <>
      <HeroCarousel />

      {/* Trust strip */}
      <section className="relative z-10 mx-auto -mt-4 max-w-7xl px-4 md:px-6">
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-3xl border border-line bg-line md:grid-cols-4">
          {[
            { icon: Wallet, t: 'Cash on Delivery', s: 'Pay when it reaches you' },
            { icon: Truck, t: 'Nationwide delivery', s: '2–5 working days' },
            { icon: RotateCcw, t: '7-day easy returns', s: 'Damaged or wrong? We fix it' },
            { icon: MessageCircle, t: 'WhatsApp support', s: settings.phoneDisplay },
          ].map(({ icon: Icon, t, s }) => (
            <div key={t} className="flex items-center gap-3 bg-panel px-5 py-5">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-brand/10 text-brand"><Icon size={20} /></div>
              <div>
                <p className="text-sm font-bold">{t}</p>
                <p className="text-xs text-mist">{s}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <Section eyebrow="Browse" title="Shop by category">
        <div className="scrollbar-none -mx-4 flex snap-x gap-4 overflow-x-auto px-4 pb-2 md:mx-0 md:grid md:grid-cols-5 md:px-0">
          {categories.map((c, i) => {
            const cover = live.find((p) => p.category === c.id)
            return (
              <Link
                key={c.id}
                to="/shop"
                search={{ c: c.id }}
                className="group relative aspect-[3/4] w-44 shrink-0 snap-start overflow-hidden rounded-3xl border border-line md:w-auto"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                {cover && (
                  <img src={img(cover.image, 400)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-110" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-4">
                  <p className="font-display text-lg font-bold">{c.name}</p>
                  <p className="text-xs text-mist">{c.blurb}</p>
                  <span className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-brand opacity-0 transition group-hover:opacity-100">
                    Shop now <ArrowRight size={12} />
                  </span>
                </div>
              </Link>
            )
          })}
        </div>
      </Section>

      {/* Promo tiles */}
      {activeTiles.length > 0 && (
        <section className="mx-auto mt-6 grid max-w-7xl auto-rows-[220px] grid-cols-1 gap-4 px-4 md:grid-cols-4 md:px-6">
          {activeTiles.map((t) => (
            <SmartLink
              key={t.id}
              href={t.link}
              className={`grain group relative overflow-hidden rounded-3xl border border-line ${
                t.size === 'large' ? 'md:col-span-2 md:row-span-2' : t.size === 'wide' ? 'md:col-span-2' : ''
              }`}
            >
              <img src={img(t.image, t.size === 'small' ? 500 : 900)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover transition duration-[1200ms] group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-tr from-ink via-ink/50 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6">
                <p className={`font-display font-extrabold leading-tight ${t.size === 'large' ? 'text-3xl md:text-4xl' : 'text-xl'}`}>{t.title}</p>
                <p className="mt-1 text-sm text-snow/75">{t.subtitle}</p>
                <span className="mt-4 inline-flex items-center gap-2 rounded-full bg-snow/10 px-4 py-2 text-xs font-bold backdrop-blur transition group-hover:bg-brand group-hover:text-ink">
                  Explore <ArrowRight size={14} />
                </span>
              </div>
            </SmartLink>
          ))}
        </section>
      )}

      {/* Flash deals */}
      <Section eyebrow="Ends tonight" title="Flash deals" action={<Countdown />}>
        <div className="scrollbar-none -mx-4 flex snap-x gap-4 overflow-x-auto px-4 pb-4 md:mx-0 md:px-0">
          {deals.map((p, i) => (
            <div key={p.id} className="w-60 shrink-0 snap-start">
              <ProductCard product={p} index={i} />
            </div>
          ))}
        </div>
      </Section>

      {/* Best sellers */}
      <Section
        eyebrow="Most loved"
        title="Best sellers"
        action={<Link to="/shop" className="flex items-center gap-1 text-sm font-bold text-brand hover:underline">View all <ArrowRight size={16} /></Link>}
      >
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {(featured.length ? featured : live).slice(0, 8).map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </Section>

      {/* Visit our store */}
      <section className="mx-auto mt-24 max-w-7xl px-4 md:px-6">
        <div className="grain relative overflow-hidden rounded-[2rem] border border-line">
          <img src={img('/img/storefront.jpg', 1400)} alt="HyperPanda SuperStore" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/20" />
          <div className="relative grid gap-8 p-8 md:grid-cols-2 md:p-14">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-accent">Real store · Real people</p>
              <h2 className="mt-3 font-display text-4xl font-extrabold leading-tight md:text-5xl">Visit {settings.storeName}</h2>
              <p className="mt-4 max-w-md text-snow/80">
                Order online with Cash on Delivery, or talk to a real human on WhatsApp — we reply fast, every day.
              </p>
              <ul className="mt-6 space-y-3 text-sm">
                <li className="flex items-start gap-3"><MapPin className="mt-0.5 shrink-0 text-brand" size={18} /> {settings.address}</li>
                <li className="flex items-start gap-3"><MessageCircle className="mt-0.5 shrink-0 text-brand" size={18} /> {settings.phoneDisplay} · {settings.supportHours}</li>
              </ul>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href={waLink(settings.whatsapp, 'Hi HyperPanda! I want to place an order.')} target="_blank" rel="noreferrer" className="btn btn-brand">
                  <MessageCircle size={18} /> Chat on WhatsApp
                </a>
                <a href={`https://maps.google.com/?q=${encodeURIComponent(settings.address)}`} target="_blank" rel="noreferrer" className="btn btn-ghost">
                  <MapPin size={18} /> Get directions
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <Section eyebrow="Reviews" title="Loved across Pakistan">
        <div className="grid gap-4 md:grid-cols-4">
          {reviews.map((r) => (
            <figure key={r.name} className="flex flex-col rounded-3xl border border-line bg-panel/70 p-6">
              <div className="flex gap-0.5 text-amber-400">
                {Array.from({ length: 5 }).map((_, i) => <Star key={i} size={14} className="fill-current" />)}
              </div>
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-snow/85">“{r.text}”</blockquote>
              <figcaption className="mt-5 flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-brand/15 font-bold text-brand">{r.name[0]}</span>
                <span className="text-xs">
                  <b className="block text-sm">{r.name}</b>
                  <span className="flex items-center gap-1 text-mist"><BadgeCheck size={12} className="text-brand" /> Verified · {r.city}</span>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </Section>

      {/* FAQ */}
      <section id="faq" className="mx-auto mt-24 grid max-w-7xl gap-10 px-4 md:grid-cols-[1fr_1.4fr] md:px-6">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-brand">Help</p>
          <h2 className="mt-2 font-display text-4xl font-extrabold">Frequently asked questions</h2>
          <p className="mt-4 text-mist">
            Can’t find what you’re looking for? WhatsApp us at{' '}
            <a className="font-bold text-brand" href={waLink(settings.whatsapp)}>{settings.phoneDisplay}</a> or email{' '}
            <a className="font-bold text-brand break-all" href={`mailto:${settings.email}`}>{settings.email}</a>.
          </p>
        </div>
        <div className="space-y-3">
          {faqs.map((f) => (
            <details key={f.q} className="group rounded-2xl border border-line bg-panel/60 px-5 py-4 open:border-brand/40">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold">
                {f.q}
                <ChevronDown size={18} className="shrink-0 transition group-open:rotate-180" />
              </summary>
              <p className="mt-3 text-sm leading-relaxed text-mist">{f.a}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  )
}

function Section({
  eyebrow,
  title,
  action,
  children,
}: {
  eyebrow: string
  title: string
  action?: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <section className="mx-auto mt-24 max-w-7xl px-4 md:px-6">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-brand">{eyebrow}</p>
          <h2 className="mt-2 font-display text-3xl font-extrabold md:text-4xl">{title}</h2>
        </div>
        {action}
      </div>
      {children}
    </section>
  )
}

function Countdown() {
  const [left, setLeft] = useState<number | null>(null)
  useEffect(() => {
    const tick = () => {
      const now = new Date()
      const end = new Date(now)
      end.setHours(23, 59, 59, 999)
      setLeft(end.getTime() - now.getTime())
    }
    tick()
    const t = setInterval(tick, 1000)
    return () => clearInterval(t)
  }, [])
  const s = Math.max(0, Math.floor((left ?? 0) / 1000))
  const parts = [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60]
  return (
    <div className="flex items-center gap-2" aria-label="Time left">
      {parts.map((v, i) => (
        <span key={i} className="flex items-center gap-2">
          <span className="grid h-12 w-12 place-items-center rounded-xl border border-accent/40 bg-accent/10 font-display text-lg font-bold tabular-nums text-accent">
            {left === null ? '--' : String(v).padStart(2, '0')}
          </span>
          {i < 2 && <span className="font-bold text-accent">:</span>}
        </span>
      ))}
    </div>
  )
}
