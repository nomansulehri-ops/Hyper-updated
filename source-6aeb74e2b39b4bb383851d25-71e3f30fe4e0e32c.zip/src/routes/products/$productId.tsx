import { Link, createFileRoute, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { BadgeCheck, Check, Minus, Plus, RotateCcw, ShoppingBag, Star, Truck, Wallet, Zap } from 'lucide-react'
import { useStore } from '@/lib/store'
import { discountPct, img, money, waLink } from '@/lib/format'
import { ProductCard } from '@/components/ProductCard'

export const Route = createFileRoute('/products/$productId')({
  component: ProductPage,
})

function ProductPage() {
  const { productId } = Route.useParams()
  const { productById, products, categories, addToCart, openCart, settings } = useStore()
  const navigate = useNavigate()
  const product = productById(productId)
  const [qty, setQty] = useState(1)
  const [active, setActive] = useState(0)

  if (!product || !product.active) {
    return (
      <div className="mx-auto max-w-xl px-6 py-32 text-center">
        <h1 className="font-display text-3xl font-bold">Product not found</h1>
        <p className="mt-3 text-mist">It may have been removed or is no longer available.</p>
        <Link to="/shop" className="btn btn-brand mt-8">Back to shop</Link>
      </div>
    )
  }

  const images = [product.image, ...product.gallery].filter(Boolean)
  const off = discountPct(product.price, product.originalPrice)
  const cat = categories.find((c) => c.id === product.category)
  const related = products.filter((p) => p.active && p.category === product.category && p.id !== product.id).slice(0, 4)
  const soldOut = product.stock <= 0

  const buyNow = () => {
    addToCart(product.id, qty)
    openCart(false)
    navigate({ to: '/checkout' })
  }

  return (
    <div className="mx-auto max-w-7xl px-4 pt-8 md:px-6">
      <nav className="mb-6 text-sm text-mist">
        <Link to="/" className="hover:text-snow">Home</Link> /{' '}
        <Link to="/shop" search={{ c: product.category }} className="hover:text-snow">{cat?.name ?? 'Shop'}</Link>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          <div className="relative aspect-square overflow-hidden rounded-[2rem] border border-line bg-white">
            <img src={img(images[active] ?? product.image, 900)} alt={product.name} className="h-full w-full animate-rise object-cover" key={active} />
            {off > 0 && <span className="absolute left-5 top-5 rounded-full bg-accent px-4 py-1.5 font-display font-extrabold text-white shadow-xl">-{off}%</span>}
          </div>
          {images.length > 1 && (
            <div className="mt-4 flex gap-3">
              {images.map((src, i) => (
                <button key={i} onClick={() => setActive(i)} className={`h-20 w-20 overflow-hidden rounded-xl border-2 bg-white ${i === active ? 'border-brand' : 'border-transparent opacity-60'}`}>
                  <img src={img(src, 160)} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="lg:py-4">
          {product.badge && <span className="rounded-full bg-brand/15 px-3 py-1 text-xs font-bold text-brand">{product.badge}</span>}
          <h1 className="mt-4 font-display text-3xl font-extrabold leading-tight md:text-4xl">{product.name}</h1>
          <div className="mt-3 flex items-center gap-3 text-sm text-mist">
            <span className="flex items-center gap-1 text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => <Star key={i} size={15} className={i < Math.round(product.rating) ? 'fill-current' : ''} />)}
            </span>
            <b className="text-snow">{product.rating.toFixed(1)}</b> · {product.reviews} reviews
          </div>

          <div className="mt-6 flex items-end gap-4">
            <span className="font-display text-4xl font-extrabold text-brand">{money(product.price, settings.currency)}</span>
            {product.originalPrice && product.originalPrice > product.price && (
              <>
                <span className="pb-1 text-lg text-mist line-through">{money(product.originalPrice, settings.currency)}</span>
                <span className="mb-1.5 rounded-md bg-accent/15 px-2 py-0.5 text-sm font-bold text-accent">Save {money(product.originalPrice - product.price, settings.currency)}</span>
              </>
            )}
          </div>

          <p className="mt-6 leading-relaxed text-snow/80">{product.description}</p>

          <ul className="mt-6 grid gap-2 sm:grid-cols-2">
            {product.highlights.map((h) => (
              <li key={h} className="flex items-start gap-2 text-sm"><Check size={16} className="mt-0.5 shrink-0 text-brand" /> {h}</li>
            ))}
          </ul>

          <p className={`mt-6 text-sm font-semibold ${product.stock < 15 ? 'text-accent' : 'text-brand'}`}>
            {soldOut ? 'Out of stock' : product.stock < 15 ? `Hurry — only ${product.stock} left in stock` : 'In stock · ready to dispatch'}
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <div className="flex items-center rounded-full border border-line">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="p-3" aria-label="Decrease"><Minus size={16} /></button>
              <span className="w-8 text-center font-bold">{qty}</span>
              <button onClick={() => setQty((q) => Math.min(product.stock, q + 1))} className="p-3" aria-label="Increase"><Plus size={16} /></button>
            </div>
            <button disabled={soldOut} onClick={() => addToCart(product.id, qty)} className="btn btn-ghost flex-1 py-3.5 disabled:opacity-40">
              <ShoppingBag size={18} /> Add to cart
            </button>
            <button disabled={soldOut} onClick={buyNow} className="btn btn-accent flex-1 py-3.5 disabled:opacity-40">
              <Zap size={18} /> Buy now · COD
            </button>
          </div>
          <a
            href={waLink(settings.whatsapp, `Hi! I want to order: ${product.name} (x${qty})`)}
            target="_blank"
            rel="noreferrer"
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-full border border-[#25d366]/40 py-3 text-sm font-bold text-[#25d366] hover:bg-[#25d366]/10"
          >
            Order on WhatsApp
          </a>

          <div className="mt-8 grid grid-cols-2 gap-3 text-sm">
            {[
              { icon: Wallet, t: 'Cash on Delivery' },
              { icon: Truck, t: `Free delivery over ${money(settings.freeShippingThreshold, settings.currency)}` },
              { icon: RotateCcw, t: '7-day easy returns' },
              { icon: BadgeCheck, t: 'Quality checked' },
            ].map(({ icon: Icon, t }) => (
              <div key={t} className="flex items-center gap-2 rounded-2xl border border-line bg-panel/60 px-4 py-3">
                <Icon size={18} className="text-brand" /> {t}
              </div>
            ))}
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-24">
          <h2 className="mb-6 font-display text-2xl font-extrabold">You may also like</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {related.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
          </div>
        </section>
      )}
    </div>
  )
}
