import { HeadContent, Scripts, createRootRoute, useRouterState } from '@tanstack/react-router'
import type { CSSProperties, ReactNode } from 'react'
import { StoreProvider, useStore } from '@/lib/store'
import { Header } from '@/components/Header'
import { Footer, WhatsAppFab } from '@/components/Footer'
import { CartDrawer } from '@/components/CartDrawer'

import '../styles.css'

const siteName = 'HyperPanda SuperStore — Gadgets, Fashion & Home Essentials in Pakistan'
const siteDescription =
  'Shop original gadgets, modest fashion, home and beauty essentials at HyperPanda SuperStore. Cash on Delivery all over Pakistan. WhatsApp +92 339 0112789.'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: siteName },
      { name: 'description', content: siteDescription },
      { name: 'theme-color', content: '#06110b' },
      { property: 'og:title', content: siteName },
      { property: 'og:description', content: siteDescription },
      { property: 'og:type', content: 'website' },
      { property: 'og:image', content: '/.netlify/images?url=/img/hero-1.png&w=1200&fm=jpg' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <StoreProvider>
          <Shell>{children}</Shell>
        </StoreProvider>
        <Scripts />
      </body>
    </html>
  )
}

function Shell({ children }: { children: ReactNode }) {
  const { settings } = useStore()
  const pathname = useRouterState({ select: (s) => s.location.pathname })
  const isAdmin = pathname.startsWith('/admin')
  // Brand colours set in /admin → Branding recolour every Tailwind utility.
  const vars = {
    '--color-brand': settings.theme.brand,
    '--color-accent': settings.theme.accent,
    '--color-ink': settings.theme.ink,
  } as CSSProperties

  return (
    <div style={vars} className="min-h-screen bg-ink text-snow">
      {isAdmin ? (
        children
      ) : (
        <>
          <Header />
          <main>{children}</main>
          <Footer />
          <CartDrawer />
          <WhatsAppFab />
        </>
      )}
    </div>
  )
}
