import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { PackageSearch } from 'lucide-react'
import type { Order } from '@/data/types'
import { useStore } from '@/lib/store'
import { waLink } from '@/lib/format'
import { OrderTracker } from '@/components/OrderTracker'

export const Route = createFileRoute('/track')({
  head: () => ({ meta: [{ title: 'Track your order — HyperPanda SuperStore' }] }),
  component: Track,
})

const norm = (s: string) => s.replace(/\D/g, '').replace(/^92/, '0')

function Track() {
  const { orders, settings } = useStore()
  const [id, setId] = useState('')
  const [phone, setPhone] = useState('')
  const [result, setResult] = useState<Order | null | undefined>(undefined)

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const o = orders.find(
      (x) => x.id.toLowerCase() === id.trim().toLowerCase() && norm(x.customer.phone) === norm(phone),
    )
    setResult(o ?? null)
  }

  return (
    <div className="mx-auto max-w-4xl px-4 pt-14 md:px-6">
      <div className="text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-brand/15 text-brand"><PackageSearch size={30} /></div>
        <h1 className="mt-5 font-display text-4xl font-extrabold md:text-5xl">Track your order</h1>
        <p className="mt-3 text-mist">Enter your order number and the mobile number you ordered with.</p>
      </div>
      <form onSubmit={submit} className="mx-auto mt-8 flex max-w-2xl flex-col gap-3 sm:flex-row">
        <input required value={id} onChange={(e) => setId(e.target.value)} placeholder="Order # e.g. HP-10427" className="input py-3.5" />
        <input required value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Mobile e.g. 03211234567" className="input py-3.5" inputMode="tel" />
        <button className="btn btn-brand shrink-0 px-8">Track</button>
      </form>
      <p className="mt-3 text-center text-xs text-mist">Try the sample order <b>HP-10427</b> with <b>03211234567</b>.</p>

      <div className="mt-10">
        {result === null && (
          <div className="rounded-3xl border border-accent/40 bg-accent/10 p-6 text-center">
            <p className="font-bold">We couldn’t find that order.</p>
            <p className="mt-1 text-sm text-mist">
              Double-check the details or{' '}
              <a className="font-bold text-brand" href={waLink(settings.whatsapp, `Hi! Please help me track order ${id}`)}>message us on WhatsApp</a>.
            </p>
          </div>
        )}
        {result && <OrderTracker order={result} currency={settings.currency} />}
      </div>
    </div>
  )
}
