import { Link, createFileRoute } from '@tanstack/react-router'
import { CheckCircle2, MessageCircle } from 'lucide-react'
import { useStore } from '@/lib/store'
import { money, waLink } from '@/lib/format'
import { OrderTracker } from '@/components/OrderTracker'

export const Route = createFileRoute('/order/$orderId')({
  head: () => ({ meta: [{ title: 'Order confirmed — HyperPanda SuperStore' }] }),
  component: OrderConfirmed,
})

function OrderConfirmed() {
  const { orderId } = Route.useParams()
  const { orders, settings } = useStore()
  const order = orders.find((o) => o.id === orderId)

  if (!order) {
    return (
      <div className="mx-auto max-w-xl px-6 py-32 text-center">
        <h1 className="font-display text-3xl font-bold">Order not found</h1>
        <Link to="/track" className="btn btn-brand mt-8">Track an order</Link>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-4xl px-4 pt-14 md:px-6">
      <div className="animate-rise text-center">
        <CheckCircle2 size={64} className="mx-auto text-brand drop-shadow-[0_0_30px_var(--color-brand)]" />
        <h1 className="mt-5 font-display text-4xl font-extrabold md:text-5xl">Shukriya, {order.customer.name.split(' ')[0]}!</h1>
        <p className="mx-auto mt-3 max-w-lg text-mist">
          Your order <b className="text-snow">{order.id}</b> is placed. Keep {money(order.total, settings.currency)} ready for the rider —
          we’ll confirm on WhatsApp shortly.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <a
            href={waLink(settings.whatsapp, `Hi! I just placed order ${order.id}. Please confirm.`)}
            target="_blank"
            rel="noreferrer"
            className="btn btn-brand"
          >
            <MessageCircle size={18} /> Confirm on WhatsApp
          </a>
          <Link to="/shop" className="btn btn-ghost">Continue shopping</Link>
        </div>
      </div>
      <div className="mt-12">
        <OrderTracker order={order} currency={settings.currency} />
      </div>
    </div>
  )
}
