import { Link, createFileRoute, useRouter } from '@tanstack/react-router'
import { useState } from 'react'
import {
  ExternalLink,
  Image as ImageIcon,
  LayoutDashboard,
  LayoutGrid,
  LogOut,
  Menu,
  Package,
  Palette,
  ShoppingCart,
  Tags,
  UserRound,
  Users,
  X,
} from 'lucide-react'
import { useStore } from '@/lib/store'
import { Logo } from '@/components/Logo'
import { Dashboard } from '@/components/admin/Dashboard'
import { OrdersAdmin } from '@/components/admin/Orders'
import { ProductsAdmin } from '@/components/admin/Products'
import { BannersAdmin, TilesAdmin } from '@/components/admin/Merch'
import { CategoriesAdmin } from '@/components/admin/Categories'
import { BrandingAdmin } from '@/components/admin/Branding'
import { AccountsAdmin, AdminLogin } from '@/components/admin/Accounts'
import { adminLogout, getAdminSession } from '@/lib/auth'
import type { AdminUser } from '@/lib/auth'

const TABS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'orders', label: 'Orders & tracking', icon: ShoppingCart },
  { id: 'products', label: 'Products', icon: Package },
  { id: 'banners', label: 'Hero banners', icon: ImageIcon },
  { id: 'tiles', label: 'Promo tiles', icon: LayoutGrid },
  { id: 'categories', label: 'Categories', icon: Tags },
  { id: 'branding', label: 'Branding & settings', icon: Palette },
  { id: 'accounts', label: 'Admin accounts', icon: Users },
] as const

type TabId = (typeof TABS)[number]['id']

export const Route = createFileRoute('/admin')({
  validateSearch: (s: Record<string, unknown>): { tab?: TabId } => ({
    tab: TABS.some((t) => t.id === s.tab) ? (s.tab as TabId) : undefined,
  }),
  head: () => ({ meta: [{ title: 'Admin — HyperPanda SuperStore' }, { name: 'robots', content: 'noindex' }] }),
  loader: () => getAdminSession(),
  staleTime: Infinity,
  component: AdminGate,
})

function AdminGate() {
  const user = Route.useLoaderData()
  const router = useRouter()
  if (!user) return <AdminLogin onSignedIn={() => router.invalidate()} />
  return <Admin me={user} />
}

function Admin({ me }: { me: AdminUser }) {
  const router = useRouter()
  const { tab = 'dashboard' } = Route.useSearch()
  const { orders } = useStore()
  const [nav, setNav] = useState(false)
  const pending = orders.filter((o) => o.status === 'pending').length

  const Sidebar = (
    <nav className="flex h-full flex-col gap-1 p-4">
      <div className="mb-6 px-2 pt-2">
        <Logo />
        <p className="mt-3 inline-block rounded-full bg-brand/15 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-brand">Admin portal</p>
      </div>
      {TABS.map((t) => (
        <Link
          key={t.id}
          to="/admin"
          search={{ tab: t.id }}
          onClick={() => setNav(false)}
          className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${
            tab === t.id ? 'bg-brand text-ink' : 'text-mist hover:bg-snow/5 hover:text-snow'
          }`}
        >
          <t.icon size={18} /> {t.label}
          {t.id === 'orders' && pending > 0 && (
            <span className={`ml-auto rounded-full px-2 text-xs ${tab === t.id ? 'bg-ink text-brand' : 'bg-accent text-white'}`}>{pending}</span>
          )}
        </Link>
      ))}
      <div className="mt-auto flex items-center gap-2 rounded-xl bg-snow/5 px-3 py-2.5 text-sm">
        <UserRound size={16} className="shrink-0 text-brand" />
        <span className="min-w-0 flex-1 truncate font-semibold">{me.name || me.username}</span>
        <button
          onClick={async () => {
            await adminLogout()
            router.invalidate()
          }}
          className="flex items-center gap-1 text-xs font-bold text-mist hover:text-accent"
        >
          <LogOut size={14} /> Sign out
        </button>
      </div>
      <Link to="/" className="flex items-center gap-2 rounded-xl border border-line px-3 py-2.5 text-sm font-semibold text-mist hover:text-snow">
        <ExternalLink size={16} /> View live store
      </Link>
    </nav>
  )

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 border-r border-line bg-panel/60 lg:block">{Sidebar}</aside>
      {nav && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/70" onClick={() => setNav(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-panel">
            <button className="absolute right-3 top-3 p-2" onClick={() => setNav(false)} aria-label="Close menu"><X /></button>
            {Sidebar}
          </aside>
        </div>
      )}
      <div className="min-w-0 flex-1">
        <div className="sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-ink/85 px-4 py-3 backdrop-blur lg:hidden">
          <button onClick={() => setNav(true)} aria-label="Open menu"><Menu /></button>
          <span className="font-display font-bold">{TABS.find((t) => t.id === tab)?.label}</span>
        </div>
        <div className="border-b border-line bg-brand/5 px-6 py-2.5 text-xs text-mist">
          Changes apply to the storefront instantly — open <Link to="/" className="font-bold text-brand">the live store</Link> to preview.
        </div>
        <main className="mx-auto max-w-6xl p-4 md:p-8">
          {tab === 'dashboard' && <Dashboard />}
          {tab === 'orders' && <OrdersAdmin />}
          {tab === 'products' && <ProductsAdmin />}
          {tab === 'banners' && <BannersAdmin />}
          {tab === 'tiles' && <TilesAdmin />}
          {tab === 'categories' && <CategoriesAdmin />}
          {tab === 'branding' && <BrandingAdmin />}
          {tab === 'accounts' && <AccountsAdmin me={me} />}
        </main>
      </div>
    </div>
  )
}
