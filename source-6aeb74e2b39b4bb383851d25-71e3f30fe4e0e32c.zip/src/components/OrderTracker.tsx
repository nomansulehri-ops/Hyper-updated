import { Check, Package, Truck, X } from 'lucide-react'
import type { Order } from '@/data/types'
import { STATUS_FLOW, STATUS_LABEL } from '@/lib/store'
import { fmtDate, img, money } from '@/lib/format'

export function OrderTracker({ order, currency = 'Rs.' }: { order: Order; currency?: string }) {
  const cancelled = order.status === 'cancelled'
  const step = STATUS_FLOW.indexOf(order.status)

  return (
    <div className="rounded-3xl border border-line bg-panel/60 p-6 md:p-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest text-mist">Order</p>
          <p className="font-display text-2xl font-extrabold">{order.id}</p>
          <p className="text-sm text-mist">Placed {fmtDate(order.createdAt)} · {order.customer.city}</p>
        </div>
        <span className={`rounded-full px-4 py-1.5 text-sm font-bold ${cancelled ? 'bg-accent/15 text-accent' : 'bg-brand/15 text-brand'}`}>
          {STATUS_LABEL[order.status]}
        </span>
      </div>

      {!cancelled && (
        <ol className="mt-8 grid grid-cols-6 gap-1">
          {STATUS_FLOW.map((s, i) => (
            <li key={s} className="flex flex-col items-center text-center">
              <div className="flex w-full items-center">
                <span className={`h-[3px] flex-1 ${i === 0 ? 'opacity-0' : i <= step ? 'bg-brand' : 'bg-line'}`} />
                <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full border-2 ${i <= step ? 'border-brand bg-brand text-ink' : 'border-line text-mist'} ${i === step ? 'shadow-[0_0_24px_var(--color-brand)]' : ''}`}>
                  {i < step ? <Check size={15} /> : i === 3 || i === 4 ? <Truck size={14} /> : <Package size={14} />}
                </span>
                <span className={`h-[3px] flex-1 ${i === STATUS_FLOW.length - 1 ? 'opacity-0' : i < step ? 'bg-brand' : 'bg-line'}`} />
              </div>
              <span className={`mt-2 text-[10px] font-semibold leading-tight sm:text-xs ${i <= step ? 'text-snow' : 'text-mist'}`}>{STATUS_LABEL[s]}</span>
            </li>
          ))}
        </ol>
      )}

      {(order.courier || order.trackingNumber) && (
        <div className="mt-6 flex flex-wrap gap-6 rounded-2xl border border-line bg-ink/50 px-5 py-4 text-sm">
          <div><p className="text-xs text-mist">Courier</p><p className="font-bold">{order.courier || '—'}</p></div>
          <div><p className="text-xs text-mist">Tracking number</p><p className="font-mono font-bold">{order.trackingNumber || '—'}</p></div>
        </div>
      )}

      <div className="mt-8 grid gap-8 md:grid-cols-2">
        <div>
          <h3 className="mb-3 text-xs font-bold uppercase tracking-widest text-mist">Updates</h3>
          <ul className="space-y-4 border-l border-line pl-5">
            {[...order.timeline].reverse().map((e, i) => (
              <li key={i} className="relative">
                <span className={`absolute -left-[26px] top-1 grid h-3 w-3 place-items-center rounded-full ${i === 0 ? (e.status === 'cancelled' ? 'bg-accent' : 'bg-brand') : 'bg-line'}`}>
                  {e.status === 'cancelled' && <X size={8} />}
                </span>
                <p className="text-sm font-semibold">{STATUS_LABEL[e.status]}</p>
                <p className="text-xs text-mist">{e.note} · {fmtDate(e.at)}</p>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="mb-3 text-xs font-bold uppercase tracking-widest text-mist">Items</h3>
          <ul className="space-y-3">
            {order.items.map((it) => (
              <li key={it.productId} className="flex items-center gap-3">
                <img src={img(it.image, 120)} alt="" className="h-12 w-12 rounded-lg bg-white object-cover" />
                <p className="line-clamp-1 flex-1 text-sm">{it.name} <span className="text-mist">× {it.qty}</span></p>
                <p className="text-sm font-semibold">{money(it.price * it.qty, currency)}</p>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex justify-between border-t border-line pt-3 font-display font-bold">
            <span>Total (COD)</span><span className="text-brand">{money(order.total, currency)}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
