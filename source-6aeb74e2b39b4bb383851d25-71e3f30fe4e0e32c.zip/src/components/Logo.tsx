import { useStore } from '@/lib/store'

/** The panda mark used when no custom logo has been uploaded from /admin. */
export function PandaMark({ className = 'h-10 w-10' }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="hp-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--color-brand)" />
          <stop offset="1" stopColor="color-mix(in oklab, var(--color-brand) 60%, black)" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="60" height="60" rx="18" fill="url(#hp-g)" />
      <circle cx="17" cy="18" r="8" fill="#0b1a11" />
      <circle cx="47" cy="18" r="8" fill="#0b1a11" />
      <ellipse cx="32" cy="35" rx="20" ry="18" fill="#fff" />
      <ellipse cx="24" cy="33" rx="5.5" ry="7" transform="rotate(-25 24 33)" fill="#0b1a11" />
      <ellipse cx="40" cy="33" rx="5.5" ry="7" transform="rotate(25 40 33)" fill="#0b1a11" />
      <circle cx="25" cy="32" r="2" fill="#fff" />
      <circle cx="39" cy="32" r="2" fill="#fff" />
      <ellipse cx="32" cy="42" rx="3.4" ry="2.4" fill="#0b1a11" />
      <path d="M28 46 q4 3 8 0" stroke="#0b1a11" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <circle cx="49" cy="49" r="7" fill="var(--color-accent)" stroke="#fff" strokeWidth="2" />
    </svg>
  )
}

export function Logo({ compact = false }: { compact?: boolean }) {
  const { settings } = useStore()
  if (settings.logoUrl) {
    return (
      <img
        src={settings.logoUrl}
        alt={settings.storeName}
        className="h-11 w-auto max-w-[180px] object-contain"
      />
    )
  }
  return (
    <span className="flex items-center gap-2.5">
      <PandaMark />
      {!compact && (
        <span className="leading-none">
          <span className="block font-logo text-2xl font-bold tracking-tight">
            <span className="text-brand">Hyper</span>
            <span className="text-snow">Pand</span>
            <span className="text-accent">a</span>
          </span>
          <span className="block text-[10px] font-semibold uppercase tracking-[0.32em] text-mist">
            SuperStore
          </span>
        </span>
      )}
    </span>
  )
}
