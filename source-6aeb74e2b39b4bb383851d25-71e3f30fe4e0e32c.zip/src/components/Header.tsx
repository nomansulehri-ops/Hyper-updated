import { Link, useNavigate } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { Menu, PackageSearch, Search, ShoppingBag, Truck, X } from 'lucide-react'
import { useStore } from '@/lib/store'
import { Logo } from './Logo'

export function Header() {
  const { settings, categories, cartCount, openCart } = useStore()
  const [scrolled, setScrolled] = useState(false)
  const [menu, setMenu] = useState(false)
  const [q, setQ] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 24)
    on()
    window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [])

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    navigate({ to: '/shop', search: { q: q || undefined } })
    setMenu(false)
  }

  const ann = settings.announcements.length ? settings.announcements : [settings.tagline]

  return (
    <header className="sticky top-0 z-40">
      <div className="overflow-hidden bg-brand py-1.5 text-xs font-bold text-ink">
        <div className="flex w-max animate-marquee gap-12 whitespace-nowrap">
          {[...ann, ...ann, ...ann, ...ann].map((a, i) => (
            <span key={i} className="flex items-center gap-2">
              <Truck size={13} /> {a}
            </span>
          ))}
        </div>
      </div>
      <div
        className={`border-b transition-all duration-300 ${
          scrolled
            ? 'border-line bg-ink/85 backdrop-blur-xl'
            : 'border-transparent bg-gradient-to-b from-ink/90 to-ink/30 backdrop-blur-sm'
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 md:px-6">
          <button className="md:hidden" onClick={() => setMenu(true)} aria-label="Open menu">
            <Menu />
          </button>
          <Link to="/" aria-label={settings.storeName}>
            <Logo />
          </Link>
          <form onSubmit={submit} className="relative mx-auto hidden max-w-md flex-1 md:block">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-mist" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search chargers, abayas, nebulizers…"
              className="w-full rounded-full border border-line bg-panel/80 py-2.5 pl-11 pr-4 text-sm outline-none placeholder:text-mist/70 focus:border-brand"
            />
          </form>
          <div className="ml-auto flex items-center gap-1 md:ml-0">
            <Link
              to="/track"
              className="hidden items-center gap-2 rounded-full px-3 py-2 text-sm font-semibold text-mist hover:text-snow sm:flex"
            >
              <PackageSearch size={18} /> Track order
            </Link>
            <button
              onClick={() => openCart()}
              className="relative flex items-center gap-2 rounded-full bg-snow/5 px-3 py-2 text-sm font-semibold hover:bg-snow/10"
              aria-label="Open cart"
            >
              <ShoppingBag size={18} />
              <span className="hidden sm:inline">Cart</span>
              {cartCount > 0 && (
                <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-accent px-1 text-[11px] font-bold text-white">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
        <nav className="mx-auto hidden max-w-7xl gap-1 px-6 pb-2 text-sm font-semibold md:flex">
          <NavItem to="/shop" label="Shop all" />
          {categories.map((c) => (
            <NavItem key={c.id} to="/shop" c={c.id} label={c.name} />
          ))}
          <Link to="/shop" search={{ sort: 'deals' }} className="ml-auto rounded-full px-3 py-1.5 text-accent hover:bg-accent/10">
            🔥 Hot deals
          </Link>
        </nav>
      </div>

      {menu && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/70" onClick={() => setMenu(false)} />
          <div className="absolute inset-y-0 left-0 flex w-80 max-w-[85%] flex-col gap-1 bg-panel p-5">
            <div className="mb-4 flex items-center justify-between">
              <Logo />
              <button onClick={() => setMenu(false)} aria-label="Close menu"><X /></button>
            </div>
            <form onSubmit={submit} className="mb-3">
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products" className="input" />
            </form>
            <Link to="/shop" onClick={() => setMenu(false)} className="rounded-lg px-3 py-2.5 font-semibold hover:bg-snow/5">Shop all</Link>
            {categories.map((c) => (
              <Link key={c.id} to="/shop" search={{ c: c.id }} onClick={() => setMenu(false)} className="rounded-lg px-3 py-2.5 font-semibold hover:bg-snow/5">
                {c.name}
              </Link>
            ))}
            <Link to="/track" onClick={() => setMenu(false)} className="rounded-lg px-3 py-2.5 font-semibold text-brand hover:bg-snow/5">Track order</Link>
          </div>
        </div>
      )}
    </header>
  )
}

function NavItem({ to, c, label }: { to: '/shop'; c?: string; label: string }) {
  return (
    <Link
      to={to}
      search={c ? { c } : {}}
      activeOptions={{ includeSearch: true }}
      className="rounded-full px-3 py-1.5 text-mist transition hover:bg-snow/5 hover:text-snow"
      activeProps={{ className: '!text-ink !bg-brand' }}
    >
      {label}
    </Link>
  )
}
