import { useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'
import { useStore } from '@/lib/store'
import { Card, PageHeader } from './ui'

export function CategoriesAdmin() {
  const { categories, products, saveCategory, remove } = useStore()
  const [name, setName] = useState('')

  const add = (e: React.FormEvent) => {
    e.preventDefault()
    const id = name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
    if (!id || categories.some((c) => c.id === id)) return
    saveCategory({ id, name: name.trim(), blurb: '' })
    setName('')
  }

  return (
    <>
      <PageHeader title="Categories" subtitle="Shown in the main menu, the category row and the shop filters." />
      <form onSubmit={add} className="mb-4 flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="New category name, e.g. Kids & Toys" className="input max-w-sm" />
        <button className="btn btn-brand"><Plus size={16} /> Add</button>
      </form>
      <Card className="divide-y divide-line">
        {categories.map((c) => {
          const count = products.filter((p) => p.category === c.id).length
          return (
            <div key={c.id} className="grid items-center gap-3 p-4 sm:grid-cols-[1fr_1.4fr_auto_auto]">
              <input value={c.name} onChange={(e) => saveCategory({ ...c, name: e.target.value })} className="input font-semibold" aria-label="Category name" />
              <input value={c.blurb} onChange={(e) => saveCategory({ ...c, blurb: e.target.value })} placeholder="Short description" className="input" aria-label="Category description" />
              <span className="text-xs text-mist">{count} products</span>
              <button
                onClick={() => (count ? alert('Move or delete the products in this category first.') : remove('categories', c.id))}
                className="rounded-lg p-2 text-mist hover:bg-snow/10 hover:text-accent"
                aria-label={`Delete ${c.name}`}
              >
                <Trash2 size={16} />
              </button>
            </div>
          )
        })}
      </Card>
    </>
  )
}
