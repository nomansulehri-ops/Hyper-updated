import { useEffect, useState } from 'react'
import { Eye, EyeOff, KeyRound, Loader2, Lock, Plus, ShieldCheck, Trash2, UserRound } from 'lucide-react'
import { adminLogin, createAdmin, deleteAdmin, listAdmins, updateAdminPassword } from '@/lib/auth'
import type { AdminUser } from '@/lib/auth'
import { Logo } from '@/components/Logo'
import { Card, Empty, Field, Modal, PageHeader } from './ui'

const errMsg = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong. Please try again.')

function PasswordInput({ value, onChange, autoComplete, autoFocus }: { value: string; onChange: (v: string) => void; autoComplete: string; autoFocus?: boolean }) {
  const [show, setShow] = useState(false)
  return (
    <div className="relative">
      <input
        type={show ? 'text' : 'password'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete={autoComplete}
        autoFocus={autoFocus}
        required
        className="input pr-11"
      />
      <button type="button" onClick={() => setShow(!show)} className="absolute inset-y-0 right-0 grid w-11 place-items-center text-mist hover:text-snow" aria-label={show ? 'Hide password' : 'Show password'}>
        {show ? <EyeOff size={16} /> : <Eye size={16} />}
      </button>
    </div>
  )
}

/** Full-screen sign-in shown on /admin until someone logs in. */
export function AdminLogin({ onSignedIn }: { onSignedIn: () => void }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setError('')
    try {
      await adminLogin({ data: { username, password } })
      onSignedIn()
    } catch (err) {
      setError(errMsg(err))
      setBusy(false)
    }
  }

  return (
    <div className="relative grid min-h-screen place-items-center overflow-hidden px-4 py-10">
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-brand/20 blur-[120px]" />
      <form onSubmit={submit} className="relative w-full max-w-sm animate-rise space-y-5 rounded-3xl border border-line bg-panel/80 p-8 shadow-2xl backdrop-blur">
        <div className="flex flex-col items-center gap-3 text-center">
          <Logo />
          <span className="inline-flex items-center gap-1.5 rounded-full bg-brand/15 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-brand">
            <Lock size={12} /> Admin portal
          </span>
          <p className="text-sm text-mist">Sign in to manage the store.</p>
        </div>
        <Field label="Username">
          <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" autoCapitalize="none" autoFocus required className="input" />
        </Field>
        <Field label="Password">
          <PasswordInput value={password} onChange={setPassword} autoComplete="current-password" />
        </Field>
        {error && <p className="rounded-xl bg-accent/15 px-3 py-2 text-sm font-semibold text-accent" role="alert">{error}</p>}
        <button disabled={busy} className="btn btn-brand w-full disabled:opacity-60">
          {busy ? <Loader2 size={16} className="animate-spin" /> : <ShieldCheck size={16} />} Sign in
        </button>
      </form>
    </div>
  )
}

/** Admin tab: create, re-key and delete admin accounts. */
export function AccountsAdmin({ me }: { me: AdminUser }) {
  const [users, setUsers] = useState<AdminUser[] | null>(null)
  const [error, setError] = useState('')
  const [adding, setAdding] = useState(false)
  const [resetFor, setResetFor] = useState<AdminUser | null>(null)

  const load = () => listAdmins().then(setUsers).catch((e) => setError(errMsg(e)))
  useEffect(() => {
    load()
  }, [])

  const del = async (u: AdminUser) => {
    if (!confirm(`Delete the admin account “${u.username}”? They will no longer be able to sign in.`)) return
    try {
      await deleteAdmin({ data: { id: u.id } })
      load()
    } catch (e) {
      alert(errMsg(e))
    }
  }

  return (
    <>
      <PageHeader
        title="Admin accounts"
        subtitle="Everyone listed here can sign in to this admin portal."
        action={<button onClick={() => setAdding(true)} className="btn btn-brand"><Plus size={16} /> New account</button>}
      />
      {error && <p className="mb-4 rounded-xl bg-accent/15 px-3 py-2 text-sm font-semibold text-accent">{error}</p>}
      {!users ? (
        <Empty><Loader2 className="mx-auto animate-spin" /></Empty>
      ) : (
        <Card className="divide-y divide-line">
          {users.map((u) => (
            <div key={u.id} className="flex flex-wrap items-center gap-4 p-4">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-brand/15 text-brand"><UserRound size={18} /></span>
              <div className="min-w-0 flex-1">
                <p className="font-semibold">
                  {u.name || u.username}
                  {u.id === me.id && <span className="ml-2 rounded-full bg-brand px-2 py-0.5 text-[10px] font-bold uppercase text-ink">You</span>}
                </p>
                <p className="text-xs text-mist">@{u.username} · added {new Date(u.createdAt).toLocaleDateString()}</p>
              </div>
              <button onClick={() => setResetFor(u)} className="btn btn-ghost px-3 py-2 text-xs"><KeyRound size={14} /> Change password</button>
              {u.id !== me.id && (
                <button onClick={() => del(u)} className="rounded-lg p-2 text-mist hover:bg-snow/10 hover:text-accent" aria-label={`Delete ${u.username}`}>
                  <Trash2 size={16} />
                </button>
              )}
            </div>
          ))}
        </Card>
      )}
      <NewAccountModal open={adding} onClose={() => setAdding(false)} onCreated={load} />
      <PasswordModal user={resetFor} onClose={() => setResetFor(null)} />
    </>
  )
}

function NewAccountModal({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: () => void }) {
  const [form, setForm] = useState({ name: '', username: '', password: '' })
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const close = () => {
    setForm({ name: '', username: '', password: '' })
    setError('')
    onClose()
  }
  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setError('')
    try {
      await createAdmin({ data: form })
      onCreated()
      close()
    } catch (err) {
      setError(errMsg(err))
    } finally {
      setBusy(false)
    }
  }
  return (
    <Modal title="New admin account" open={open} onClose={close}>
      <form onSubmit={submit} className="space-y-4">
        <Field label="Name"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Ali (store staff)" className="input" /></Field>
        <Field label="Username" hint="3–32 characters: letters, numbers, . _ - or @">
          <input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} autoCapitalize="none" autoComplete="off" required className="input" />
        </Field>
        <Field label="Password" hint="At least 6 characters.">
          <PasswordInput value={form.password} onChange={(password) => setForm({ ...form, password })} autoComplete="new-password" />
        </Field>
        {error && <p className="rounded-xl bg-accent/15 px-3 py-2 text-sm font-semibold text-accent" role="alert">{error}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" onClick={close} className="btn btn-ghost">Cancel</button>
          <button disabled={busy} className="btn btn-brand disabled:opacity-60">{busy && <Loader2 size={16} className="animate-spin" />} Create account</button>
        </div>
      </form>
    </Modal>
  )
}

function PasswordModal({ user, onClose }: { user: AdminUser | null; onClose: () => void }) {
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const close = () => {
    setPassword('')
    setError('')
    onClose()
  }
  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return
    setBusy(true)
    setError('')
    try {
      await updateAdminPassword({ data: { id: user.id, password } })
      close()
    } catch (err) {
      setError(errMsg(err))
    } finally {
      setBusy(false)
    }
  }
  return (
    <Modal title={`Change password — @${user?.username ?? ''}`} open={!!user} onClose={close}>
      <form onSubmit={submit} className="space-y-4">
        <Field label="New password" hint="At least 6 characters.">
          <PasswordInput value={password} onChange={setPassword} autoComplete="new-password" autoFocus />
        </Field>
        {error && <p className="rounded-xl bg-accent/15 px-3 py-2 text-sm font-semibold text-accent" role="alert">{error}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" onClick={close} className="btn btn-ghost">Cancel</button>
          <button disabled={busy} className="btn btn-brand disabled:opacity-60">{busy && <Loader2 size={16} className="animate-spin" />} Save password</button>
        </div>
      </form>
    </Modal>
  )
}
