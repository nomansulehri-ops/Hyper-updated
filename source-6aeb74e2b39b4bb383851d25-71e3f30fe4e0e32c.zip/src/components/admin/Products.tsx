import { useState } from 'react'
import { Copy, Eye, EyeOff, Pencil, Plus, Search, Trash2 } from 'lucide-react'
import type { Product } from '@/data/types'
import { useStore } from '@/lib/store'
import { discountPct, img, money } from '@/lib/format'
import { Card, Empty, Field, ImageInput, Modal, PageHeader, Toggle } from './ui'

const blank = (category: string): Product => ({
  id: String(Date.now()),
  name: '',
  category,
  price: 0,
  originalPrice: undefined,
  image: '',
  gallery: [],
  description: '',
  highlights: [],
  stock: 10,
  rating: 5,
  reviews: 0,
  badge: '',
  featured: false,
  active: true,
})

export function ProductsAdmin() {
  const { products, categories, saveProduct, remove, settings } = useStore()
  const [editing, setEditing] = useState<Product | null>(null)
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('all')

  const list = products.filter(
    (p) => (cat === 'all' || p.category === cat) && p.name.toLowerCase().includes(q.toLowerCase()),
  )

  return (
    <>
      <PageHeader
        title="Products"
        subtitle={`${products.length} products · edit prices, stock, photos and descriptions`}
        action={<button onClick={() => setEditing(blank(categories[0]?.id ?? ''))} className="btn btn-brand"><Plus size={16} /> Add product</button>}
      />
      <div className="mb-4 flex flex-wrap gap-2">
        <div className="relative w-full sm:w-72">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-mist" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products" className="input pl-9" />
        </div>
        <select value={cat} onChange={(e) => setCat(e.target.value)} className="input w-auto">
          <option value="all">All categories</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {list.length === 0 ? (
        <Empty>No products yet.</Empty>
      ) : (
        <Card className="divide-y divide-line">
          {list.map((p) => (
            <div key={p.id} className={`flex items-center gap-4 p-4 ${p.active ? '' : 'opacity-50'}`}>
              <img src={img(p.image, 120)} alt="" className="h-14 w-14 shrink-0 rounded-xl bg-white object-cover" />
              <div className="min-w-0 flex-1">
                <p className="line-clamp-1 font-semibold">{p.name || 'Untitled product'}</p>
                <p className="text-xs text-mist">
                  {categories.find((c) => c.id === p.category)?.name ?? '—'} ·{' '}
                  <span className={p.stock < 15 ? 'font-bold text-accent' : ''}>{p.stock} in stock</span>
                  {p.featured && <span className="ml-2 rounded bg-brand/15 px-1.5 text-brand">Best seller</span>}
                </p>
              </div>
              <div className="hidden text-right sm:block">
                <p className="font-bold text-brand">{money(p.price, settings.currency)}</p>
                {discountPct(p.price, p.originalPrice) > 0 && <p className="text-xs text-mist">-{discountPct(p.price, p.originalPrice)}%</p>}
              </div>
              <div className="flex gap-1">
                <IconBtn label={p.active ? 'Hide from store' : 'Show in store'} onClick={() => saveProduct({ ...p, active: !p.active })}>{p.active ? <Eye size={16} /> : <EyeOff size={16} />}</IconBtn>
                <IconBtn label="Duplicate" onClick={() => setEditing({ ...p, id: String(Date.now()), name: `${p.name} (copy)` })}><Copy size={16} /></IconBtn>
                <IconBtn label="Edit" onClick={() => setEditing(p)}><Pencil size={16} /></IconBtn>
                <IconBtn label="Delete" danger onClick={() => confirm(`Delete “${p.name}”?`) && remove('products', p.id)}><Trash2 size={16} /></IconBtn>
              </div>
            </div>
          ))}
        </Card>
      )}

      {editing && <ProductEditor key={editing.id} initial={editing} onClose={() => setEditing(null)} />}
    </>
  )
}

export function IconBtn({ children, label, onClick, danger }: { children: React.ReactNode; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button type="button" title={label} aria-label={label} onClick={onClick} className={`rounded-lg p-2 text-mist transition hover:bg-snow/10 ${danger ? 'hover:text-accent' : 'hover:text-snow'}`}>
      {children}
    </button>
  )
}

function ProductEditor({ initial, onClose }: { initial: Product; onClose: () => void }) {
  const { categories, saveProduct } = useStore()
  const [p, setP] = useState(initial)
  const [highlights, setHighlights] = useState(initial.highlights.join('\n'))
  const [gallery, setGallery] = useState(initial.gallery.join('\n'))
  const set = <K extends keyof Product>(k: K, v: Product[K]) => setP((x) => ({ ...x, [k]: v }))

  const save = (e: React.FormEvent) => {
    e.preventDefault()
    saveProduct({
      ...p,
      highlights: highlights.split('\n').map((s) => s.trim()).filter(Boolean),
      gallery: gallery.split('\n').map((s) => s.trim()).filter(Boolean),
      originalPrice: p.originalPrice || undefined,
    })
    onClose()
  }

  return (
    <Modal
      open
      title={initial.name ? 'Edit product' : 'New product'}
      onClose={onClose}
      footer={
        <>
          <button onClick={onClose} className="btn btn-ghost">Cancel</button>
          <button form="product-form" className="btn btn-brand">Save product</button>
        </>
      }
    >
      <form id="product-form" onSubmit={save} className="space-y-4">
        <Field label="Product name"><input required value={p.name} onChange={(e) => set('name', e.target.value)} className="input" /></Field>
        <ImageInput label="Main photo" value={p.image} onChange={(v) => set('image', v)} aspect="aspect-square" />
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Sale price (Rs.)"><input required type="number" min={0} value={p.price || ''} onChange={(e) => set('price', Number(e.target.value))} className="input" /></Field>
          <Field label="Original price" hint="Leave empty for no discount"><input type="number" min={0} value={p.originalPrice ?? ''} onChange={(e) => set('originalPrice', e.target.value ? Number(e.target.value) : undefined)} className="input" /></Field>
          <Field label="Stock"><input type="number" min={0} value={p.stock} onChange={(e) => set('stock', Number(e.target.value))} className="input" /></Field>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Category">
            <select value={p.category} onChange={(e) => set('category', e.target.value)} className="input">
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="Badge" hint="e.g. New, Trending, Best seller"><input value={p.badge ?? ''} onChange={(e) => set('badge', e.target.value)} className="input" /></Field>
        </div>
        <Field label="Description"><textarea rows={4} value={p.description} onChange={(e) => set('description', e.target.value)} className="input" /></Field>
        <Field label="Highlights" hint="One per line"><textarea rows={3} value={highlights} onChange={(e) => setHighlights(e.target.value)} className="input" /></Field>
        <Field label="Extra gallery image URLs" hint="One per line (optional)"><textarea rows={2} value={gallery} onChange={(e) => setGallery(e.target.value)} className="input" /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Rating"><input type="number" step="0.1" min={0} max={5} value={p.rating} onChange={(e) => set('rating', Number(e.target.value))} className="input" /></Field>
          <Field label="Review count"><input type="number" min={0} value={p.reviews} onChange={(e) => set('reviews', Number(e.target.value))} className="input" /></Field>
        </div>
        <div className="flex flex-wrap gap-6 pt-2">
          <Toggle checked={p.active} onChange={(v) => set('active', v)} label="Visible in store" />
          <Toggle checked={p.featured} onChange={(v) => set('featured', v)} label="Show in Best sellers" />
        </div>
      </form>
    </Modal>
  )
}
