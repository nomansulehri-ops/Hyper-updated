import { useState } from 'react'
import { Check, RotateCcw } from 'lucide-react'
import type { StoreSettings } from '@/data/types'
import { seedSettings } from '@/data/fixtures'
import { useStore } from '@/lib/store'
import { Logo } from '@/components/Logo'
import { Card, Field, ImageInput, PageHeader } from './ui'

const PRESETS = [
  { name: 'HyperPanda Green', brand: '#3fb53a', accent: '#f26b2a', ink: '#06110b' },
  { name: 'Royal Gold', brand: '#e8b54a', accent: '#e2483d', ink: '#0d0b07' },
  { name: 'Ocean', brand: '#38bdf8', accent: '#f472b6', ink: '#050d16' },
  { name: 'Ruby Night', brand: '#f43f5e', accent: '#facc15', ink: '#12060a' },
]

export function BrandingAdmin() {
  const { settings, updateSettings } = useStore()
  const [draft, setDraft] = useState<StoreSettings>(settings)
  const [announce, setAnnounce] = useState(settings.announcements.join('\n'))
  const [saved, setSaved] = useState(false)
  const set = <K extends keyof StoreSettings>(k: K, v: StoreSettings[K]) => setDraft((d) => ({ ...d, [k]: v }))
  const setTheme = (patch: Partial<StoreSettings['theme']>) => {
    const theme = { ...draft.theme, ...patch }
    set('theme', theme)
    updateSettings({ theme }) // colours preview live
  }

  const save = (e: React.FormEvent) => {
    e.preventDefault()
    updateSettings({ ...draft, announcements: announce.split('\n').map((s) => s.trim()).filter(Boolean) })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <form onSubmit={save}>
      <PageHeader
        title="Branding & settings"
        subtitle="Logo, store name, colours, contact details, delivery charges and the announcement bar."
        action={<button className="btn btn-brand">{saved ? <><Check size={16} /> Saved</> : 'Save changes'}</button>}
      />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="space-y-4 p-6">
          <h2 className="font-display font-bold">Identity</h2>
          <div className="rounded-2xl border border-line bg-ink p-5">
            <p className="mb-3 text-xs font-bold uppercase tracking-wider text-mist">Live logo preview</p>
            <Logo />
          </div>
          <ImageInput label="Logo image" value={draft.logoUrl} onChange={(v) => { set('logoUrl', v); updateSettings({ logoUrl: v }) }} aspect="aspect-[3/1]" />
          {draft.logoUrl && (
            <button type="button" onClick={() => { set('logoUrl', ''); updateSettings({ logoUrl: '' }) }} className="text-xs font-bold text-brand">
              Use the built-in HyperPanda logo
            </button>
          )}
          <Field label="Store name"><input value={draft.storeName} onChange={(e) => set('storeName', e.target.value)} className="input" /></Field>
          <Field label="Tagline (footer & SEO)"><textarea rows={3} value={draft.tagline} onChange={(e) => set('tagline', e.target.value)} className="input" /></Field>
        </Card>

        <Card className="space-y-4 p-6">
          <h2 className="font-display font-bold">Theme colours</h2>
          <div className="grid grid-cols-2 gap-2">
            {PRESETS.map((p) => (
              <button
                type="button"
                key={p.name}
                onClick={() => setTheme({ brand: p.brand, accent: p.accent, ink: p.ink })}
                className={`flex items-center gap-3 rounded-xl border p-3 text-left text-sm font-semibold ${draft.theme.brand === p.brand ? 'border-brand' : 'border-line'}`}
              >
                <span className="flex -space-x-1.5">
                  {[p.brand, p.accent, p.ink].map((c) => <span key={c} className="h-6 w-6 rounded-full border-2 border-panel" style={{ background: c }} />)}
                </span>
                {p.name}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-3">
            {(['brand', 'accent', 'ink'] as const).map((k) => (
              <Field key={k} label={k === 'brand' ? 'Primary' : k === 'accent' ? 'Accent' : 'Background'}>
                <div className="flex items-center gap-2 rounded-xl border border-line p-1.5">
                  <input type="color" value={draft.theme[k]} onChange={(e) => setTheme({ [k]: e.target.value })} className="h-8 w-10 cursor-pointer rounded bg-transparent" />
                  <span className="font-mono text-xs">{draft.theme[k]}</span>
                </div>
              </Field>
            ))}
          </div>
          <button type="button" onClick={() => setTheme(seedSettings.theme)} className="flex items-center gap-1 text-xs font-bold text-mist hover:text-snow">
            <RotateCcw size={12} /> Reset to HyperPanda colours
          </button>

          <h2 className="pt-4 font-display font-bold">Announcement bar</h2>
          <Field label="Messages" hint="One per line — they scroll across the top of every page">
            <textarea rows={5} value={announce} onChange={(e) => setAnnounce(e.target.value)} className="input" />
          </Field>
        </Card>

        <Card className="space-y-4 p-6">
          <h2 className="font-display font-bold">Customer care</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="WhatsApp number" hint="International format, digits only"><input value={draft.whatsapp} onChange={(e) => set('whatsapp', e.target.value.replace(/\D/g, ''))} className="input" /></Field>
            <Field label="Phone (as displayed)"><input value={draft.phoneDisplay} onChange={(e) => set('phoneDisplay', e.target.value)} className="input" /></Field>
          </div>
          <Field label="Email"><input type="email" value={draft.email} onChange={(e) => set('email', e.target.value)} className="input" /></Field>
          <Field label="Store address"><input value={draft.address} onChange={(e) => set('address', e.target.value)} className="input" /></Field>
          <Field label="Support hours"><input value={draft.supportHours} onChange={(e) => set('supportHours', e.target.value)} className="input" /></Field>
        </Card>

        <Card className="space-y-4 p-6">
          <h2 className="font-display font-bold">Delivery & pricing</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Currency label"><input value={draft.currency} onChange={(e) => set('currency', e.target.value)} className="input" /></Field>
            <Field label="Delivery fee"><input type="number" min={0} value={draft.shippingFee} onChange={(e) => set('shippingFee', Number(e.target.value))} className="input" /></Field>
            <Field label="Free delivery over"><input type="number" min={0} value={draft.freeShippingThreshold} onChange={(e) => set('freeShippingThreshold', Number(e.target.value))} className="input" /></Field>
          </div>
          <h2 className="pt-4 font-display font-bold">Social links</h2>
          {(['facebook', 'instagram', 'tiktok'] as const).map((k) => (
            <Field key={k} label={k}>
              <input value={draft.social[k]} onChange={(e) => set('social', { ...draft.social, [k]: e.target.value })} placeholder={`https://${k}.com/…`} className="input" />
            </Field>
          ))}
        </Card>
      </div>
    </form>
  )
}
