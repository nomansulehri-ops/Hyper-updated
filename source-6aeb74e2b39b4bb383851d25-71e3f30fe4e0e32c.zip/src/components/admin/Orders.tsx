import { useState } from 'react'
import { MessageCircle, Phone, Search } from 'lucide-react'
import type { Order, OrderStatus } from '@/data/types'
import { STATUS_FLOW, STATUS_LABEL, useStore } from '@/lib/store'
import { fmtDate, img, money, waLink } from '@/lib/format'
import { Card, Empty, Field, Modal, PageHeader } from './ui'
import { StatusPill } from './Dashboard'

const COURIERS = ['TCS', 'Leopards', 'M&P', 'Trax', 'PostEx', 'BlueEx', 'Call Courier', 'Pakistan Post', 'Self delivery']
const FILTERS: Array<OrderStatus | 'all'> = ['all', ...STATUS_FLOW, 'cancelled']

export function OrdersAdmin() {
  const { orders, settings } = useStore()
  const [filter, setFilter] = useState<OrderStatus | 'all'>('all')
  const [q, setQ] = useState('')
  const [openId, setOpenId] = useState<string | null>(null)

  const list = orders.filter((o) => {
    if (filter !== 'all' && o.status !== filter) return false
    if (!q) return true
    const t = q.toLowerCase()
    return `${o.id} ${o.customer.name} ${o.customer.phone} ${o.customer.city} ${o.trackingNumber}`.toLowerCase().includes(t)
  })
  const open = orders.find((o) => o.id === openId)

  return (
    <>
      <PageHeader title="Orders & tracking" subtitle="Confirm orders, assign couriers, add tracking numbers and update delivery status." />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {FILTERS.map((f) => {
          const n = f === 'all' ? orders.length : orders.filter((o) => o.status === f).length
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full border px-3 py-1.5 text-xs font-bold ${filter === f ? 'border-brand bg-brand text-ink' : 'border-line text-mist hover:text-snow'}`}
            >
              {f === 'all' ? 'All' : STATUS_LABEL[f]} <span className="opacity-60">{n}</span>
            </button>
          )
        })}
        <div className="relative ml-auto w-full sm:w-64">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-mist" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search order, name, phone…" className="input pl-9" />
        </div>
      </div>

      {list.length === 0 ? (
        <Empty>No orders match.</Empty>
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="text-left text-xs uppercase tracking-wider text-mist">
              <tr className="border-b border-line">
                <th className="px-5 py-3">Order</th>
                <th className="px-5 py-3">Customer</th>
                <th className="px-5 py-3">Items</th>
                <th className="px-5 py-3">Tracking</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {list.map((o) => (
                <tr key={o.id} onClick={() => setOpenId(o.id)} className="cursor-pointer transition hover:bg-snow/5">
                  <td className="px-5 py-3"><b className="font-mono">{o.id}</b><p className="text-xs text-mist">{fmtDate(o.createdAt)}</p></td>
                  <td className="px-5 py-3">{o.customer.name}<p className="text-xs text-mist">{o.customer.phone} · {o.customer.city}</p></td>
                  <td className="px-5 py-3">
                    <div className="flex -space-x-2">
                      {o.items.slice(0, 3).map((it) => <img key={it.productId} src={img(it.image, 64)} alt="" className="h-8 w-8 rounded-full border-2 border-panel bg-white object-cover" />)}
                    </div>
                  </td>
                  <td className="px-5 py-3 text-xs">{o.trackingNumber ? <><b>{o.courier}</b><p className="font-mono text-mist">{o.trackingNumber}</p></> : <span className="text-mist">—</span>}</td>
                  <td className="px-5 py-3"><StatusPill status={o.status} /></td>
                  <td className="px-5 py-3 text-right font-bold">{money(o.total, settings.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {open && <OrderEditor key={open.id} order={open} onClose={() => setOpenId(null)} />}
    </>
  )
}

function OrderEditor({ order, onClose }: { order: Order; onClose: () => void }) {
  const { updateOrder, settings } = useStore()
  const [status, setStatus] = useState<OrderStatus>(order.status)
  const [note, setNote] = useState('')
  const [courier, setCourier] = useState(order.courier)
  const [tracking, setTracking] = useState(order.trackingNumber)

  const save = () => {
    updateOrder(order.id, { status, courier, trackingNumber: tracking }, note || undefined)
    onClose()
  }

  const next = STATUS_FLOW[STATUS_FLOW.indexOf(order.status) + 1]
  const msg = `Assalam-o-Alaikum ${order.customer.name}! Your ${settings.storeName} order ${order.id} is now: ${STATUS_LABEL[status]}.${
    tracking ? ` Courier: ${courier}, tracking #${tracking}.` : ''
  } Total: ${money(order.total, settings.currency)} (COD).`

  return (
    <Modal
      open
      title={`Order ${order.id}`}
      onClose={onClose}
      footer={
        <>
          <button onClick={onClose} className="btn btn-ghost">Close</button>
          <button onClick={save} className="btn btn-brand">Save changes</button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Card className="p-4 text-sm">
          <p className="font-bold">{order.customer.name}</p>
          <p className="text-mist">{order.customer.address}, {order.customer.city}</p>
          {order.customer.email && <p className="text-mist">{order.customer.email}</p>}
          {order.customer.notes && <p className="mt-2 rounded-lg bg-amber-400/10 px-2 py-1 text-xs text-amber-300">Note: {order.customer.notes}</p>}
          <div className="mt-3 flex gap-2">
            <a href={waLink(order.customer.phone.replace(/^0/, '92'), msg)} target="_blank" rel="noreferrer" className="btn btn-brand px-3 py-1.5 text-xs"><MessageCircle size={14} /> WhatsApp update</a>
            <a href={`tel:${order.customer.phone}`} className="btn btn-ghost px-3 py-1.5 text-xs"><Phone size={14} /> Call</a>
          </div>
        </Card>
        <Card className="p-4 text-sm">
          <ul className="space-y-2">
            {order.items.map((it) => (
              <li key={it.productId} className="flex items-center gap-2">
                <img src={img(it.image, 64)} alt="" className="h-8 w-8 rounded bg-white object-cover" />
                <span className="line-clamp-1 flex-1">{it.name}</span>
                <span className="text-mist">×{it.qty}</span>
              </li>
            ))}
          </ul>
          <div className="mt-3 border-t border-line pt-2 text-xs text-mist">
            Subtotal {money(order.subtotal, settings.currency)} · Delivery {money(order.shipping, settings.currency)}
            <p className="font-display text-base font-bold text-brand">Total {money(order.total, settings.currency)} · COD</p>
          </div>
        </Card>
      </div>

      <div>
        <span className="mb-2 block text-xs font-bold uppercase tracking-wider text-mist">Status</span>
        <div className="flex flex-wrap gap-2">
          {[...STATUS_FLOW, 'cancelled' as const].map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setStatus(s)}
              className={`rounded-full border px-3 py-1.5 text-xs font-bold ${status === s ? (s === 'cancelled' ? 'border-accent bg-accent text-white' : 'border-brand bg-brand text-ink') : 'border-line text-mist hover:text-snow'}`}
            >
              {STATUS_LABEL[s]}
            </button>
          ))}
        </div>
        {next && status === order.status && (
          <button type="button" onClick={() => setStatus(next)} className="mt-2 text-xs font-bold text-brand">Advance to “{STATUS_LABEL[next]}” →</button>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Courier">
          <select value={courier} onChange={(e) => setCourier(e.target.value)} className="input">
            <option value="">Not assigned</option>
            {COURIERS.map((c) => <option key={c}>{c}</option>)}
          </select>
        </Field>
        <Field label="Tracking number"><input value={tracking} onChange={(e) => setTracking(e.target.value)} className="input font-mono" placeholder="e.g. TCS77810342" /></Field>
      </div>
      <Field label="Update note (shown to customer)" hint="Optional — e.g. “Handed to TCS, arriving Thursday”">
        <input value={note} onChange={(e) => setNote(e.target.value)} className="input" />
      </Field>

      <div>
        <span className="mb-2 block text-xs font-bold uppercase tracking-wider text-mist">History</span>
        <ul className="space-y-1 text-xs text-mist">
          {[...order.timeline].reverse().map((e, i) => (
            <li key={i}><b className="text-snow">{STATUS_LABEL[e.status]}</b> — {e.note} · {fmtDate(e.at)}</li>
          ))}
        </ul>
      </div>
    </Modal>
  )
}
