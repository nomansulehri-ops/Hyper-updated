import { Link } from '@tanstack/react-router'
import { AlertTriangle, Banknote, Clock, Package, ShoppingCart, TrendingUp } from 'lucide-react'
import { STATUS_LABEL, useStore } from '@/lib/store'
import { fmtDate, img, money } from '@/lib/format'
import { Card, PageHeader } from './ui'

export function Dashboard() {
  const { orders, products, settings } = useStore()
  const live = orders.filter((o) => o.status !== 'cancelled')
  const revenue = live.reduce((s, o) => s + o.total, 0)
  const delivered = orders.filter((o) => o.status === 'delivered').reduce((s, o) => s + o.total, 0)
  const pending = orders.filter((o) => o.status === 'pending')
  const lowStock = products.filter((p) => p.stock < 15)
  const aov = live.length ? revenue / live.length : 0

  // Units sold per product
  const units = new Map<string, number>()
  for (const o of live) for (const it of o.items) units.set(it.productId, (units.get(it.productId) ?? 0) + it.qty)
  const top = [...units.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5)

  const kpis = [
    { label: 'Gross sales', value: money(revenue, settings.currency), icon: TrendingUp, tone: 'text-brand' },
    { label: 'Cash collected', value: money(delivered, settings.currency), icon: Banknote, tone: 'text-brand' },
    { label: 'Orders', value: String(orders.length), icon: ShoppingCart, tone: 'text-snow' },
    { label: 'Awaiting confirmation', value: String(pending.length), icon: Clock, tone: 'text-accent' },
  ]

  return (
    <>
      <PageHeader title="Assalam-o-Alaikum 👋" subtitle={`Here’s how ${settings.storeName} is doing today.`} />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {kpis.map((k) => (
          <Card key={k.label} className="p-5">
            <div className="flex items-center justify-between text-mist">
              <span className="text-xs font-bold uppercase tracking-wider">{k.label}</span>
              <k.icon size={18} />
            </div>
            <p className={`mt-3 font-display text-2xl font-extrabold tabular-nums ${k.tone}`}>{k.value}</p>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display font-bold">Recent orders</h2>
            <Link to="/admin" search={{ tab: 'orders' }} className="text-sm font-bold text-brand">Manage →</Link>
          </div>
          <ul className="divide-y divide-line">
            {orders.slice(0, 6).map((o) => (
              <li key={o.id} className="flex items-center gap-3 py-3 text-sm">
                <span className="font-mono font-bold">{o.id}</span>
                <span className="hidden flex-1 truncate text-mist sm:block">{o.customer.name} · {o.customer.city}</span>
                <span className="ml-auto text-xs text-mist">{fmtDate(o.createdAt)}</span>
                <StatusPill status={o.status} />
                <span className="w-24 text-right font-bold">{money(o.total, settings.currency)}</span>
              </li>
            ))}
          </ul>
        </Card>

        <div className="space-y-6">
          <Card className="p-5">
            <h2 className="mb-4 font-display font-bold">Top sellers</h2>
            <ul className="space-y-3">
              {top.map(([id, n]) => {
                const p = products.find((x) => x.id === id)
                if (!p) return null
                return (
                  <li key={id} className="flex items-center gap-3">
                    <img src={img(p.image, 80)} alt="" className="h-10 w-10 rounded-lg bg-white object-cover" />
                    <span className="line-clamp-1 flex-1 text-sm">{p.name}</span>
                    <span className="text-sm font-bold text-brand">{n} sold</span>
                  </li>
                )
              })}
            </ul>
            <p className="mt-4 border-t border-line pt-3 text-xs text-mist">Average order value: <b className="text-snow">{money(aov, settings.currency)}</b></p>
          </Card>
          <Card className="p-5">
            <h2 className="mb-4 flex items-center gap-2 font-display font-bold"><AlertTriangle size={16} className="text-accent" /> Low stock</h2>
            {lowStock.length === 0 ? (
              <p className="text-sm text-mist">All products are well stocked.</p>
            ) : (
              <ul className="space-y-2 text-sm">
                {lowStock.map((p) => (
                  <li key={p.id} className="flex items-center gap-2">
                    <Package size={14} className="text-mist" />
                    <span className="line-clamp-1 flex-1">{p.name}</span>
                    <span className="font-bold text-accent">{p.stock} left</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </>
  )
}

export function StatusPill({ status }: { status: keyof typeof STATUS_LABEL }) {
  const tone =
    status === 'cancelled'
      ? 'bg-accent/15 text-accent'
      : status === 'delivered'
        ? 'bg-brand text-ink'
        : status === 'pending'
          ? 'bg-amber-400/15 text-amber-300'
          : 'bg-brand/15 text-brand'
  return <span className={`whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-bold ${tone}`}>{STATUS_LABEL[status]}</span>
}
