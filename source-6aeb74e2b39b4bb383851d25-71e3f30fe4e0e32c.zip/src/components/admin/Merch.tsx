import { useState } from 'react'
import { ArrowDown, ArrowUp, Eye, EyeOff, Pencil, Plus, Trash2 } from 'lucide-react'
import type { Banner, Tile } from '@/data/types'
import { useStore } from '@/lib/store'
import { img, uid } from '@/lib/format'
import { Card, Empty, Field, ImageInput, Modal, PageHeader, Toggle } from './ui'
import { IconBtn } from './Products'

/* ---------------- Hero banners ---------------- */

export function BannersAdmin() {
  const { banners, saveBanner, remove, move } = useStore()
  const [editing, setEditing] = useState<Banner | null>(null)

  return (
    <>
      <PageHeader
        title="Hero banners"
        subtitle="The full-screen cinematic slideshow at the top of the home page. Drag order with the arrows."
        action={
          <button
            onClick={() => setEditing({ id: uid('bn'), eyebrow: '', title: '', subtitle: '', image: '', ctaLabel: 'Shop now', ctaLink: '/shop', active: true })}
            className="btn btn-brand"
          >
            <Plus size={16} /> Add banner
          </button>
        }
      />
      {banners.length === 0 && <Empty>No banners — the hero section is hidden.</Empty>}
      <div className="space-y-4">
        {banners.map((b, i) => (
          <Card key={b.id} className={`flex flex-col overflow-hidden sm:flex-row ${b.active ? '' : 'opacity-50'}`}>
            <div className="relative aspect-video shrink-0 bg-ink sm:w-72">
              {b.image && <img src={img(b.image, 600)} alt="" className="absolute inset-0 h-full w-full object-cover" />}
              <span className="absolute left-3 top-3 rounded-full bg-ink/80 px-2 py-0.5 text-xs font-bold">Slide {i + 1}</span>
            </div>
            <div className="flex flex-1 flex-col p-5">
              <p className="text-xs font-bold uppercase tracking-widest text-brand">{b.eyebrow}</p>
              <p className="mt-1 font-display text-xl font-extrabold">{b.title || 'Untitled banner'}</p>
              <p className="mt-1 line-clamp-2 text-sm text-mist">{b.subtitle}</p>
              <p className="mt-2 text-xs text-mist">Button: <b className="text-snow">{b.ctaLabel}</b> → {b.ctaLink}</p>
              <div className="mt-auto flex gap-1 pt-3">
                <IconBtn label="Move up" onClick={() => move('banners', b.id, -1)}><ArrowUp size={16} /></IconBtn>
                <IconBtn label="Move down" onClick={() => move('banners', b.id, 1)}><ArrowDown size={16} /></IconBtn>
                <IconBtn label={b.active ? 'Hide' : 'Show'} onClick={() => saveBanner({ ...b, active: !b.active })}>{b.active ? <Eye size={16} /> : <EyeOff size={16} />}</IconBtn>
                <IconBtn label="Edit" onClick={() => setEditing(b)}><Pencil size={16} /></IconBtn>
                <IconBtn label="Delete" danger onClick={() => confirm('Delete this banner?') && remove('banners', b.id)}><Trash2 size={16} /></IconBtn>
              </div>
            </div>
          </Card>
        ))}
      </div>
      {editing && <BannerEditor key={editing.id} initial={editing} onClose={() => setEditing(null)} />}
    </>
  )
}

function BannerEditor({ initial, onClose }: { initial: Banner; onClose: () => void }) {
  const { saveBanner } = useStore()
  const [b, setB] = useState(initial)
  const set = <K extends keyof Banner>(k: K, v: Banner[K]) => setB((x) => ({ ...x, [k]: v }))
  return (
    <Modal
      open
      title="Edit banner"
      onClose={onClose}
      footer={<><button onClick={onClose} className="btn btn-ghost">Cancel</button><button onClick={() => { saveBanner(b); onClose() }} className="btn btn-brand">Save banner</button></>}
    >
      <ImageInput label="Background image (wide, 16:9)" value={b.image} onChange={(v) => set('image', v)} />
      <Field label="Small label above title"><input value={b.eyebrow} onChange={(e) => set('eyebrow', e.target.value)} className="input" placeholder="Winter sale · up to 50% off" /></Field>
      <Field label="Headline"><input value={b.title} onChange={(e) => set('title', e.target.value)} className="input" /></Field>
      <Field label="Sub-text"><textarea rows={2} value={b.subtitle} onChange={(e) => set('subtitle', e.target.value)} className="input" /></Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Button text"><input value={b.ctaLabel} onChange={(e) => set('ctaLabel', e.target.value)} className="input" /></Field>
        <Field label="Button link" hint="e.g. /shop?c=fashion or /products/123"><input value={b.ctaLink} onChange={(e) => set('ctaLink', e.target.value)} className="input" /></Field>
      </div>
      <Toggle checked={b.active} onChange={(v) => set('active', v)} label="Show on home page" />
    </Modal>
  )
}

/* ---------------- Promo tiles ---------------- */

export function TilesAdmin() {
  const { tiles, saveTile, remove, move } = useStore()
  const [editing, setEditing] = useState<Tile | null>(null)
  return (
    <>
      <PageHeader
        title="Promo tiles"
        subtitle="The image mosaic below the categories. Large tiles take 2×2, wide take 2×1."
        action={
          <button onClick={() => setEditing({ id: uid('tl'), title: '', subtitle: '', image: '', link: '/shop', size: 'small', active: true })} className="btn btn-brand">
            <Plus size={16} /> Add tile
          </button>
        }
      />
      {tiles.length === 0 && <Empty>No tiles yet.</Empty>}
      <div className="grid gap-4 sm:grid-cols-2">
        {tiles.map((t) => (
          <Card key={t.id} className={`overflow-hidden ${t.active ? '' : 'opacity-50'}`}>
            <div className="relative aspect-[16/9] bg-ink">
              {t.image && <img src={img(t.image, 600)} alt="" className="absolute inset-0 h-full w-full object-cover" />}
              <div className="absolute inset-0 bg-gradient-to-t from-ink to-transparent" />
              <span className="absolute right-3 top-3 rounded-full bg-ink/80 px-2 py-0.5 text-xs font-bold capitalize">{t.size}</span>
              <div className="absolute bottom-3 left-4">
                <p className="font-display font-bold">{t.title || 'Untitled tile'}</p>
                <p className="text-xs text-mist">{t.subtitle}</p>
              </div>
            </div>
            <div className="flex gap-1 p-2">
              <IconBtn label="Move up" onClick={() => move('tiles', t.id, -1)}><ArrowUp size={16} /></IconBtn>
              <IconBtn label="Move down" onClick={() => move('tiles', t.id, 1)}><ArrowDown size={16} /></IconBtn>
              <IconBtn label={t.active ? 'Hide' : 'Show'} onClick={() => saveTile({ ...t, active: !t.active })}>{t.active ? <Eye size={16} /> : <EyeOff size={16} />}</IconBtn>
              <IconBtn label="Edit" onClick={() => setEditing(t)}><Pencil size={16} /></IconBtn>
              <IconBtn label="Delete" danger onClick={() => confirm('Delete this tile?') && remove('tiles', t.id)}><Trash2 size={16} /></IconBtn>
            </div>
          </Card>
        ))}
      </div>
      {editing && <TileEditor key={editing.id} initial={editing} onClose={() => setEditing(null)} />}
    </>
  )
}

function TileEditor({ initial, onClose }: { initial: Tile; onClose: () => void }) {
  const { saveTile } = useStore()
  const [t, setT] = useState(initial)
  const set = <K extends keyof Tile>(k: K, v: Tile[K]) => setT((x) => ({ ...x, [k]: v }))
  return (
    <Modal
      open
      title="Edit tile"
      onClose={onClose}
      footer={<><button onClick={onClose} className="btn btn-ghost">Cancel</button><button onClick={() => { saveTile(t); onClose() }} className="btn btn-brand">Save tile</button></>}
    >
      <ImageInput value={t.image} onChange={(v) => set('image', v)} />
      <Field label="Title"><input value={t.title} onChange={(e) => set('title', e.target.value)} className="input" /></Field>
      <Field label="Sub-text"><input value={t.subtitle} onChange={(e) => set('subtitle', e.target.value)} className="input" /></Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Link"><input value={t.link} onChange={(e) => set('link', e.target.value)} className="input" /></Field>
        <Field label="Size">
          <select value={t.size} onChange={(e) => set('size', e.target.value as Tile['size'])} className="input">
            <option value="large">Large (2×2)</option>
            <option value="wide">Wide (2×1)</option>
            <option value="small">Small (1×1)</option>
          </select>
        </Field>
      </div>
      <Toggle checked={t.active} onChange={(v) => set('active', v)} label="Show on home page" />
    </Modal>
  )
}
