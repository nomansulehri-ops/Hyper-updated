import { useEffect, useRef } from 'react'
import type { ReactNode } from 'react'
import { ImagePlus, Upload, X } from 'lucide-react'
import { fileToDataUrl, img } from '@/lib/format'

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="font-display text-2xl font-extrabold md:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-mist">{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-2xl border border-line bg-panel/70 ${className}`}>{children}</div>
}

export function Field({ label, hint, children, className = '' }: { label: string; hint?: string; children: ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-mist">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-mist/70">{hint}</span>}
    </label>
  )
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center gap-3 text-sm font-semibold"
      aria-pressed={checked}
    >
      <span className={`relative h-6 w-11 rounded-full transition ${checked ? 'bg-brand' : 'bg-line'}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
      </span>
      {label}
    </button>
  )
}

export function Modal({ title, open, onClose, children, footer }: { title: string; open: boolean; onClose: () => void; children: ReactNode; footer?: ReactNode }) {
  useEffect(() => {
    if (!open) return
    const on = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative flex max-h-[92vh] w-full max-w-2xl animate-rise flex-col rounded-t-3xl border border-line bg-panel shadow-2xl sm:rounded-3xl">
        <div className="flex items-center justify-between border-b border-line px-6 py-4">
          <h2 className="font-display text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="rounded-full p-1.5 hover:bg-snow/10" aria-label="Close"><X size={18} /></button>
        </div>
        <div className="flex-1 space-y-4 overflow-y-auto px-6 py-5">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-line px-6 py-4">{footer}</div>}
      </div>
    </div>
  )
}

/** Paste an image URL or upload a file from the device. */
export function ImageInput({ value, onChange, label = 'Image', aspect = 'aspect-video' }: { value: string; onChange: (v: string) => void; label?: string; aspect?: string }) {
  const ref = useRef<HTMLInputElement>(null)
  return (
    <Field label={label}>
      <div className="flex gap-4">
        <button
          type="button"
          onClick={() => ref.current?.click()}
          className={`relative w-36 shrink-0 overflow-hidden rounded-xl border border-dashed border-line bg-ink/60 ${aspect} grid place-items-center text-mist hover:border-brand`}
        >
          {value ? <img src={img(value, 300)} alt="" className="absolute inset-0 h-full w-full object-cover" /> : <ImagePlus />}
        </button>
        <div className="flex flex-1 flex-col gap-2">
          <input value={value.startsWith('data:') ? '' : value} onChange={(e) => onChange(e.target.value)} placeholder={value.startsWith('data:') ? 'Uploaded from device ✓ — paste a URL to replace' : 'https://… or /img/…'} className="input" />
          <button type="button" onClick={() => ref.current?.click()} className="btn btn-ghost w-fit px-4 py-2 text-xs">
            <Upload size={14} /> Upload from device
          </button>
          <input
            ref={ref}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0]
              if (f) onChange(await fileToDataUrl(f))
              e.target.value = ''
            }}
          />
        </div>
      </div>
    </Field>
  )
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-mist">{children}</div>
}
