import { Link } from '@tanstack/react-router'
import { Mail, MapPin, MessageCircle, Phone } from 'lucide-react'
import { useStore } from '@/lib/store'
import { waLink } from '@/lib/format'
import { Logo } from './Logo'

export function Footer() {
  const { settings, categories } = useStore()
  return (
    <footer className="relative mt-24 border-t border-line bg-panel/60">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 md:grid-cols-4">
        <div className="md:col-span-1">
          <Logo />
          <p className="mt-4 text-sm leading-relaxed text-mist">{settings.tagline}</p>
          <div className="mt-4 flex gap-3 text-sm font-semibold">
            {(Object.entries(settings.social) as Array<[string, string]>)
              .filter(([, url]) => url)
              .map(([name, url]) => (
                <a key={name} href={url} target="_blank" rel="noreferrer" className="capitalize text-mist hover:text-brand">{name}</a>
              ))}
          </div>
        </div>
        <div>
          <h4 className="mb-4 font-display text-sm font-bold uppercase tracking-widest text-snow">Customer care</h4>
          <ul className="space-y-3 text-sm text-mist">
            <li>
              <a href={waLink(settings.whatsapp)} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-brand">
                <MessageCircle size={16} className="text-brand" /> {settings.phoneDisplay} (WhatsApp)
              </a>
            </li>
            <li>
              <a href={`tel:+${settings.whatsapp}`} className="flex items-center gap-2 hover:text-brand">
                <Phone size={16} className="text-brand" /> {settings.supportHours}
              </a>
            </li>
            <li>
              <a href={`mailto:${settings.email}`} className="flex items-center gap-2 break-all hover:text-brand">
                <Mail size={16} className="shrink-0 text-brand" /> {settings.email}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <MapPin size={16} className="mt-0.5 shrink-0 text-brand" /> {settings.address}
            </li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 font-display text-sm font-bold uppercase tracking-widest text-snow">Shop</h4>
          <ul className="space-y-2 text-sm text-mist">
            {categories.map((c) => (
              <li key={c.id}>
                <Link to="/shop" search={{ c: c.id }} className="hover:text-brand">{c.name}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="mb-4 font-display text-sm font-bold uppercase tracking-widest text-snow">Help</h4>
          <ul className="space-y-2 text-sm text-mist">
            <li><Link to="/track" className="hover:text-brand">Track your order</Link></li>
            <li><Link to="/" hash="faq" className="hover:text-brand">FAQs</Link></li>
            <li><a href={waLink(settings.whatsapp, 'Hi! I want to return / exchange an item.')} className="hover:text-brand">Returns & exchanges</a></li>
            <li><Link to="/admin" className="hover:text-brand">Store admin</Link></li>
          </ul>
          <div className="mt-6 flex flex-wrap gap-2 text-[11px] font-bold">
            {['Cash on Delivery', 'Bank transfer', 'JazzCash', 'Easypaisa'].map((m) => (
              <span key={m} className="rounded-md border border-line px-2 py-1 text-mist">{m}</span>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-line py-5 text-center text-xs text-mist">
        © {new Date().getFullYear()} {settings.storeName}. All rights reserved.
      </div>
    </footer>
  )
}

export function WhatsAppFab() {
  const { settings } = useStore()
  return (
    <a
      href={waLink(settings.whatsapp, `Hi ${settings.storeName}! I have a question.`)}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-30 grid h-14 w-14 place-items-center rounded-full bg-[#25d366] text-white shadow-[0_10px_40px_-6px_#25d366] transition hover:scale-110"
    >
      <svg viewBox="0 0 24 24" className="h-7 w-7 fill-current" aria-hidden="true">
        <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.88 1.21 3.08.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.7.63.71.22 1.36.19 1.87.12.57-.09 1.76-.72 2-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.5h-.01a9.4 9.4 0 0 1-4.8-1.31l-.34-.2-3.56.93.95-3.47-.22-.36a9.4 9.4 0 0 1-1.44-5.01c0-5.2 4.24-9.43 9.44-9.43 2.52 0 4.89.98 6.67 2.77a9.37 9.37 0 0 1 2.76 6.67c0 5.2-4.23 9.42-9.43 9.42m8.02-17.44A11.27 11.27 0 0 0 12.05.75C5.8.75.7 5.84.7 12.1c0 2 .52 3.95 1.52 5.67L.6 23.25l5.6-1.47a11.3 11.3 0 0 0 5.85 1.5c6.25 0 11.34-5.09 11.35-11.35 0-3.03-1.18-5.88-3.33-8.03" />
      </svg>
    </a>
  )
}
