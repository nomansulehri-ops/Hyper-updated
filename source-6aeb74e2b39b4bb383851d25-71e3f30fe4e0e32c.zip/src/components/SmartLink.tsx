import { useRouter } from '@tanstack/react-router'
import type { AnchorHTMLAttributes } from 'react'

/**
 * Link for admin-editable destinations (banner CTAs, tiles). Internal paths
 * like "/shop?c=fashion" navigate client-side; anything else opens normally.
 */
export function SmartLink({ href = '/', onClick, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement>) {
  const router = useRouter()
  const internal = href.startsWith('/')
  return (
    <a
      href={href}
      target={internal ? undefined : '_blank'}
      rel={internal ? undefined : 'noreferrer'}
      onClick={(e) => {
        onClick?.(e)
        if (internal && !e.metaKey && !e.ctrlKey && !e.defaultPrevented) {
          e.preventDefault()
          router.history.push(href)
        }
      }}
      {...rest}
    />
  )
}
