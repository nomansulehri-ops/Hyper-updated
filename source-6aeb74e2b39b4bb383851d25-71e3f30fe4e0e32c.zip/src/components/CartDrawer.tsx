import { Link } from '@tanstack/react-router'
import { Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react'
import { useStore } from '@/lib/store'
import { img, money } from '@/lib/format'

export function CartDrawer() {
  const { cartOpen, openCart, cartItems, setQty, subtotal, shipping, total, settings } = useStore()
  const remaining = settings.freeShippingThreshold - subtotal
  const pct = Math.min(100, (subtotal / settings.freeShippingThreshold) * 100)

  return (
    <div className={`fixed inset-0 z-50 ${cartOpen ? '' : 'pointer-events-none'}`} aria-hidden={!cartOpen}>
      <div
        onClick={() => openCart(false)}
        className={`absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity duration-300 ${cartOpen ? 'opacity-100' : 'opacity-0'}`}
      />
      <aside
        className={`absolute inset-y-0 right-0 flex w-full max-w-md flex-col border-l border-line bg-panel shadow-2xl transition-transform duration-500 ease-[cubic-bezier(.2,.7,.2,1)] ${cartOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="flex items-center justify-between border-b border-line px-6 py-5">
          <h2 className="font-display text-xl font-bold">Your cart</h2>
          <button onClick={() => openCart(false)} aria-label="Close cart" className="rounded-full p-1.5 hover:bg-snow/10"><X /></button>
        </div>

        {cartItems.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="grid h-20 w-20 place-items-center rounded-full bg-brand/10 text-brand"><ShoppingBag size={34} /></div>
            <p className="font-display text-lg font-bold">Your cart is empty</p>
            <p className="text-sm text-mist">Add a few favourites and they will show up here.</p>
            <Link to="/shop" onClick={() => openCart(false)} className="btn btn-brand">Start shopping</Link>
          </div>
        ) : (
          <>
            <div className="border-b border-line px-6 py-4 text-sm">
              {remaining > 0 ? (
                <p>Add <b className="text-brand">{money(remaining, settings.currency)}</b> more for <b>free delivery</b></p>
              ) : (
                <p className="font-semibold text-brand">🎉 You unlocked free delivery!</p>
              )}
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-line">
                <div className="h-full rounded-full bg-gradient-to-r from-brand to-accent transition-all duration-500" style={{ width: `${pct}%` }} />
              </div>
            </div>
            <ul className="flex-1 space-y-4 overflow-y-auto px-6 py-5">
              {cartItems.map((l) => (
                <li key={l.productId} className="flex gap-4">
                  <img src={img(l.product.image, 160)} alt="" className="h-20 w-20 rounded-xl bg-white object-cover" />
                  <div className="flex flex-1 flex-col">
                    <p className="line-clamp-2 text-sm font-semibold">{l.product.name}</p>
                    <p className="text-sm font-bold text-brand">{money(l.product.price, settings.currency)}</p>
                    <div className="mt-auto flex items-center gap-2">
                      <div className="flex items-center rounded-full border border-line">
                        <button onClick={() => setQty(l.productId, l.qty - 1)} className="p-1.5" aria-label="Decrease"><Minus size={14} /></button>
                        <span className="w-6 text-center text-sm font-bold">{l.qty}</span>
                        <button onClick={() => setQty(l.productId, Math.min(l.product.stock, l.qty + 1))} className="p-1.5" aria-label="Increase"><Plus size={14} /></button>
                      </div>
                      <button onClick={() => setQty(l.productId, 0)} className="ml-auto p-1.5 text-mist hover:text-accent" aria-label="Remove"><Trash2 size={16} /></button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="space-y-2 border-t border-line px-6 py-5 text-sm">
              <div className="flex justify-between text-mist"><span>Subtotal</span><span>{money(subtotal, settings.currency)}</span></div>
              <div className="flex justify-between text-mist"><span>Delivery</span><span>{shipping === 0 ? 'Free' : money(shipping, settings.currency)}</span></div>
              <div className="flex justify-between pt-1 font-display text-lg font-bold"><span>Total</span><span>{money(total, settings.currency)}</span></div>
              <Link to="/checkout" onClick={() => openCart(false)} className="btn btn-brand mt-3 w-full">Checkout · Cash on Delivery</Link>
            </div>
          </>
        )}
      </aside>
    </div>
  )
}
