import { Link } from '@tanstack/react-router'
import { ShoppingBag, Star } from 'lucide-react'
import type { Product } from '@/data/types'
import { useStore } from '@/lib/store'
import { discountPct, img, money } from '@/lib/format'

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const { addToCart, settings } = useStore()
  const off = discountPct(product.price, product.originalPrice)
  const soldOut = product.stock <= 0

  return (
    <div
      className="group relative flex animate-rise flex-col overflow-hidden rounded-3xl border border-line bg-panel/70 transition duration-500 hover:-translate-y-1 hover:border-brand/50 hover:shadow-[0_30px_80px_-30px_var(--color-brand)]"
      style={{ animationDelay: `${(index % 8) * 60}ms` }}
    >
      <Link to="/products/$productId" params={{ productId: product.id }} className="relative block aspect-square overflow-hidden bg-white">
        <img
          src={img(product.image, 500)}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent opacity-0 transition group-hover:opacity-100" />
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {off > 0 && (
            <span className="rounded-full bg-accent px-2.5 py-1 text-xs font-extrabold text-white shadow-lg">-{off}%</span>
          )}
          {product.badge && (
            <span className="rounded-full bg-ink/80 px-2.5 py-1 text-[11px] font-bold text-brand backdrop-blur">{product.badge}</span>
          )}
        </div>
        {soldOut && (
          <div className="absolute inset-0 grid place-items-center bg-ink/70 font-display text-lg font-bold">Sold out</div>
        )}
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-center gap-1 text-xs text-mist">
          <Star size={13} className="fill-amber-400 text-amber-400" />
          <span className="font-bold text-snow">{product.rating.toFixed(1)}</span>
          <span>({product.reviews})</span>
        </div>
        <Link to="/products/$productId" params={{ productId: product.id }} className="line-clamp-2 text-sm font-semibold leading-snug hover:text-brand">
          {product.name}
        </Link>
        <div className="mt-auto flex items-end justify-between gap-2 pt-2">
          <div>
            <div className="font-display text-lg font-extrabold text-brand">{money(product.price, settings.currency)}</div>
            {product.originalPrice && product.originalPrice > product.price && (
              <div className="text-xs text-mist line-through">{money(product.originalPrice, settings.currency)}</div>
            )}
          </div>
          <button
            disabled={soldOut}
            onClick={() => addToCart(product.id)}
            className="grid h-10 w-10 place-items-center rounded-full bg-brand text-ink transition hover:scale-110 hover:shadow-[0_8px_30px_-4px_var(--color-brand)] disabled:opacity-40"
            aria-label={`Add ${product.name} to cart`}
          >
            <ShoppingBag size={18} />
          </button>
        </div>
      </div>
    </div>
  )
}
