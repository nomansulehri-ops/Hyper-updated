import { Link } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react'
import { useStore } from '@/lib/store'
import { img } from '@/lib/format'
import { SmartLink } from './SmartLink'

const DURATION = 7000

export function HeroCarousel() {
  const { banners } = useStore()
  const slides = banners.filter((b) => b.active)
  const [i, setI] = useState(0)
  const [paused, setPaused] = useState(false)
  const n = slides.length

  useEffect(() => {
    if (n < 2 || paused) return
    const t = setTimeout(() => setI((x) => (x + 1) % n), DURATION)
    return () => clearTimeout(t)
  }, [i, n, paused])

  useEffect(() => {
    if (i >= n) setI(0)
  }, [n, i])

  if (n === 0) return null
  const go = (d: number) => setI((x) => (x + d + n) % n)

  return (
    <section
      className="grain relative -mt-[120px] h-[92vh] min-h-[560px] overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {slides.map((s, idx) => {
        const on = idx === i % n
        return (
          <div
            key={s.id}
            className={`absolute inset-0 transition-opacity duration-[1400ms] ${on ? 'opacity-100' : 'opacity-0'}`}
            aria-hidden={!on}
          >
            <img
              src={img(s.image, 1920, 82)}
              srcSet={s.image.startsWith('/') ? `${img(s.image, 960)} 960w, ${img(s.image, 1600)} 1600w, ${img(s.image, 2400)} 2400w` : undefined}
              sizes="100vw"
              alt=""
              fetchPriority={idx === 0 ? 'high' : 'auto'}
              className={`absolute inset-0 h-full w-full object-cover ${on ? 'animate-kenburns' : ''}`}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/70 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/50" />
            {on && (
              <div className="relative mx-auto flex h-full max-w-7xl items-center px-6 pt-24">
                <div className="max-w-2xl">
                  <p className="mb-5 inline-flex animate-rise items-center gap-2 rounded-full border border-brand/40 bg-brand/10 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-brand backdrop-blur">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent" /> {s.eyebrow}
                  </p>
                  <h1 className="animate-rise font-display text-5xl font-extrabold leading-[1.02] tracking-tight [animation-delay:120ms] sm:text-6xl lg:text-7xl">
                    <span className="text-gradient">{s.title}</span>
                  </h1>
                  <p className="mt-6 max-w-xl animate-rise text-lg leading-relaxed text-snow/80 [animation-delay:240ms]">
                    {s.subtitle}
                  </p>
                  <div className="mt-9 flex animate-rise flex-wrap gap-3 [animation-delay:360ms]">
                    <SmartLink href={s.ctaLink} className="btn btn-brand px-7 py-4 text-base">
                      {s.ctaLabel} <ArrowRight size={18} />
                    </SmartLink>
                    <Link to="/shop" search={{ sort: 'deals' }} className="btn btn-ghost px-7 py-4 text-base">
                      View all deals
                    </Link>
                  </div>
                </div>
              </div>
            )}
          </div>
        )
      })}

      {n > 1 && (
        <div className="absolute inset-x-0 bottom-10 z-10 mx-auto flex max-w-7xl items-center gap-4 px-6">
          <div className="flex flex-1 gap-2">
            {slides.map((s, idx) => (
              <button key={s.id} onClick={() => setI(idx)} className="group h-8 flex-1 max-w-36" aria-label={`Show slide ${idx + 1}`}>
                <span className="block h-[3px] overflow-hidden rounded-full bg-snow/20">
                  <span
                    key={`${i}-${paused}`}
                    className="block h-full rounded-full bg-brand"
                    style={{
                      width: idx < i ? '100%' : idx === i ? undefined : '0%',
                      animation: idx === i && !paused ? `hp-progress ${DURATION}ms linear forwards` : undefined,
                    }}
                  />
                </span>
                <span className={`mt-2 block truncate text-left text-[11px] font-semibold uppercase tracking-widest ${idx === i ? 'text-snow' : 'text-snow/40 group-hover:text-snow/70'}`}>
                  {s.eyebrow.split('·')[0]}
                </span>
              </button>
            ))}
          </div>
          <button onClick={() => go(-1)} className="grid h-11 w-11 place-items-center rounded-full border border-snow/20 backdrop-blur hover:bg-snow/10" aria-label="Previous slide"><ChevronLeft /></button>
          <button onClick={() => go(1)} className="grid h-11 w-11 place-items-center rounded-full border border-snow/20 backdrop-blur hover:bg-snow/10" aria-label="Next slide"><ChevronRight /></button>
        </div>
      )}
      <style>{`@keyframes hp-progress{from{width:0}to{width:100%}}`}</style>
    </section>
  )
}
