export interface StoreSettings {
  storeName: string
  tagline: string
  /** Uploaded logo image (URL or data URL). Empty = built-in HyperPanda wordmark. */
  logoUrl: string
  whatsapp: string
  phoneDisplay: string
  email: string
  address: string
  supportHours: string
  currency: string
  shippingFee: number
  freeShippingThreshold: number
  announcements: Array<string>
  theme: {
    brand: string
    accent: string
    ink: string
  }
  social: { facebook: string; instagram: string; tiktok: string }
}

export interface Banner {
  id: string
  eyebrow: string
  title: string
  subtitle: string
  image: string
  ctaLabel: string
  ctaLink: string
  active: boolean
}

export interface Tile {
  id: string
  title: string
  subtitle: string
  image: string
  link: string
  /** Size on the home page mosaic */
  size: 'large' | 'wide' | 'small'
  active: boolean
}

export interface Category {
  id: string
  name: string
  blurb: string
}

export interface Product {
  id: string
  name: string
  category: string
  price: number
  originalPrice?: number
  image: string
  gallery: Array<string>
  description: string
  highlights: Array<string>
  stock: number
  rating: number
  reviews: number
  badge?: string
  featured: boolean
  active: boolean
}

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'packed'
  | 'shipped'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled'

export interface OrderItem {
  productId: string
  name: string
  image: string
  price: number
  qty: number
}

export interface TrackingEvent {
  status: OrderStatus
  note: string
  at: string
}

export interface Order {
  id: string
  createdAt: string
  customer: {
    name: string
    phone: string
    email: string
    city: string
    address: string
    notes: string
  }
  items: Array<OrderItem>
  subtotal: number
  shipping: number
  total: number
  payment: 'COD'
  status: OrderStatus
  courier: string
  trackingNumber: string
  timeline: Array<TrackingEvent>
}

export interface CartLine {
  productId: string
  qty: number
}
